@extends('layouts.app')

@section('content')
    <div class="container" style="padding-bottom: 64px;">
        {!! Form::open(['url' => route('users.first.store')]) !!}
        <div class="row">
            <div class="col-md-8 col-md-offset-2">.
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        Personal Details
                    </div>
                    <div class="panel-body" style="padding: 32px;">
                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            {!! Form::label('name', 'Name', ['class' => 'control-label']) !!}
                            {!! Form::text('name', old('name'), ['class' => 'form-control']) !!}
                            @if ($errors->has('name'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('name') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        Credentials
                    </div>
                    <div class="panel-body" style="padding: 32px;">
                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            {!! Form::label('email', 'Email', ['class' => 'control-label']) !!}
                            {!! Form::text('email', old('email'), ['class' => 'form-control']) !!}
                            @if ($errors->has('email'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('email') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            {!! Form::label('password', 'Password', ['class' => 'control-label']) !!}
                            {!! Form::password('password', ['class' => 'form-control']) !!}
                            @if ($errors->has('password'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('password') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            {!! Form::label('password_confirmation', 'Confirm Password', ['class' => 'control-label']) !!}
                            {!! Form::password('password_confirmation', ['class' => 'form-control']) !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        User Belongs To...
                    </div>
                    <div class="panel-body" style="padding: 32px;">
                        <div class="form-group{{ $errors->has('category_name') ? ' has-error' : '' }}">
                            {!! Form::label('category_name', 'Category Name', ['class' => 'control-label']) !!}
                            {!! Form::text('category_name', old('category_name'), ['class' => 'form-control']) !!}
                            @if ($errors->has('category_name'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('category_name') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="form-group{{ $errors->has('group_name') ? ' has-error' : '' }}">
                            {!! Form::label('group_name', 'Group Name', ['class' => 'control-label']) !!}
                            {!! Form::text('group_name', old('group_name'), ['class' => 'form-control']) !!}
                            @if ($errors->has('group_name'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('group_name') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
            </div>
                {!! Form::submit('Create User', ['class' => 'btn btn-primary']) !!}
                {!! Form::close() !!}
        </div>
        </div>
    </div>
@endsection