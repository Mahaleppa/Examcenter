@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="panel panel-default">
            @if(!!count($reliedSchedules))
                <div class="panel-body" style="padding: 28px;">

                    <div class="page-header text-center" style="margin-top: 0;">
                        <h3>Oops..! <i class="em em-face_with_one_eyebrow_raised" style="font-size: large;"></i></h3>
                        <h6 class="text-muted text-center">You cannot delete exam {{ $exam->name }}</h6>
                    </div>


                    <span class="help-block alert alert-danger">
                        @if(count($reliedSchedules) > 1)
                            Schedules
                        @else
                            Schedule
                        @endif
                        @foreach($reliedSchedules as $schedule)
                            <a href="{{ $schedule->link() }}">
                                    {{ $schedule->id }}@php echo ($reliedSchedules->last() != $schedule) ? ', ' :  '';  @endphp
                                </a>
                        @endforeach
                        relies on exam <strong>{{ $exam->name }}</strong> and are still running.
                        Please finish
                        @if(count($reliedSchedules) > 1)
                            them
                        @else
                            it
                        @endif
                        before deleting this exam.
                    </span>

                    <span class="pull-right" style="margin: .5em;">
                        <a href="{{ $exam->link() }}" class="btn btn-link btn-sm" style="margin-right: 1em;"><span class="glyphicon glyphicon-remove"></span> Cancel</a>
                    </span>
                </div>

            @else

                <div class="panel-body" style="padding: 28px;">

                    <div class="page-header text-center" style="margin-top: 0;">
                        <h3>Are you sure? <i class="em em-face_with_one_eyebrow_raised" style="font-size: large;"></i></h3>
                    </div>

                    <span class="pull-left" style="margin: .5em;">
                        <span class="text-muted">You cannot undo deletion of exam {{ $exam->name }}</span>
                    </span>
                    <span class="pull-right" style="margin: .5em;">
                        <form action="{{ route('exams.delete', ['exam' => $exam->id]) }}" method="post" >
                            {{ method_field('DELETE') }}
                            {{ csrf_field() }}
                            <button class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span> Delete</button>
                        </form>
                    </span>
                    <span class="pull-right" style="margin: .5em;">
                        <a href="{{ $exam->link() }}" class="btn btn-link btn-sm" style="margin-right: 1em;"><span class="glyphicon glyphicon-remove"></span> Cancel</a>
                    </span>


                </div>

            @endif


        </div>
    </div>
@endsection
