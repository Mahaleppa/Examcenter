@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5>{{ $group->name }}</h5>
                </span>
                <span class="pull-right category-modifiers" style="margin: .7em;">
                    <a href="{{ route('groups.edit.name.view', ['group' => $group->id]) }}"
                       class="btn btn-link btn-sm" style="margin-right: 1em;" data-toggle="tooltip" title="Edit name">
                        <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                    <a href="{{ route('groups.delete.view', ['group' => $group->id]) }}"
                       class="btn btn-danger btn-sm" style="margin-right: 1em;" data-toggle="tooltip" title="Delete">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7">
                <div class="panel panel-default">
                    <div class="panel-heading" style="display: inline-block; width: 100%;">
                        <div class="pull-left">
                            Users in {{ $group->name }}
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="list-group" style="margin-bottom: 0;">
                            @forelse($group->users as $user)
                                <a class="list-group-item" href="{{ $user->link() }}"
                                   style="border: 0; @php echo ($group->users->first() == $user) ?: 'border-top: 1px solid #f5f5f5;'; @endphp">
                                    {{ $user->name }}
                                    <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                </a>
                            @empty
                                <li class="text-muted list-group-item" style="border: 0;">
                                    No users assigned to this group
                                </li>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="panel panel-default">
                    <div class="panel-heading">
                      Group Details
                    </div>
                    <div class="panel-body">
                        <ul class="list-group" style="margin-bottom: 0;">
                            <li class="list-group-item" style="border: 0;">
                                Created by: <a href="{{ $group->creator->link() }}">
                                   {{ $group->creator->name }}
                                        </a>
                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Created: {{ $group->created_at->diffForHumans() }}
                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Last updated: {{ $group->updated_at->diffForHumans() }}
                            </li>
                        </ul>

                    </div>
                </div>
            </div>
            <div class="col-md-5 col-md-offset-7">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Category List
                    </div>
                    <div class="panel-body">
                        <ul class="list-group" style="margin-bottom:0">
                            @forelse($group->categories as $category)
                                <a class="list-group-item" href="{{ $category->link() }}"
                                   style="border: 0; @php echo ($group->categories->first() == $category) ?: 'border-top: 1px solid #f5f5f5;'; @endphp">
                                    {{ $category->name }}
                                    <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                </a>
                            @empty
                                <li class="text-muted list-group-item" style="border: 0;">
                                    This group is not assigned to any category
                                </li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>

@endsection