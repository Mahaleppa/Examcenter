@extends('layouts.app')

@section('content')
    <div class="container" style="padding-bottom: 64px;">
        {!! Form::open(['url' => route('groups.store')]) !!}
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        Create Group
                    </div>
                    <div class="panel-body" style="padding: 32px;">
                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            {!! Form::label('name', 'Name', ['class' => 'control-label']) !!}
                            {!! Form::text('name', old('name'), ['class' => 'form-control']) !!}
                            <li class="list-group-item col-md-6" style="border: 0;">
                            {!! Form::checkbox('is_admin', 'is_admin', false ) !!}
                            {!! Form::label('is_admin', ' isAdmin?', ['class' => 'control-label']) !!}
                            </li>
                                @if ($errors->has('name'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('name') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                </div>
                {!! Form::submit('Create Group', ['class' => 'btn btn-primary']) !!}
            </div>
        </div>
        {!! Form::close() !!}
    </div>
@endsection
