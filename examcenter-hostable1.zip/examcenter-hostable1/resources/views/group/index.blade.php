@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5>All Groups</h5>
                </span>
                <span class="pull-right category-modifiers">
                    <a href="{{ route('groups.create') }}"
                       class="btn btn-link" style="margin-right: 1em; vertical-align: middle; margin: .4em;" data-toggle="tooltip" title="Create Group">
                        <span class="glyphicon glyphicon-plus"></span>
                    </a>
                </span>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                @forelse($groups as $group)
                    <a class="list-group-item" href="{{ $group->link() }}"
                       style="border: 0; @php echo ($group->first() == $group) ?: 'border-top: 1px solid #f5f5f5;'; @endphp">
                        {{ $group->name }}
                        <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                    </a>
                @empty
                    <li class="list-group-item text-muted" style="border: 0;">
                        No groups available
                    </li>
                @endforelse
            </div>
        </div>
    </div>
    </div>
@endsection
