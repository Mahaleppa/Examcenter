@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="panel panel-default">
            @if(!!count($reliedUsers))
                <div class="panel-body" style="padding: 28px;">

                    <div class="page-header text-center" style="margin-top: 0;">
                        <h3>Oops..! <i class="em em-face_with_one_eyebrow_raised" style="font-size: large;"></i></h3>
                        <h6 class="text-muted text-center">You cannot delete Group {{ $group->name }}</h6>
                    </div>

                    <span class="help-block alert alert-danger">
                        @if(count($reliedUsers) > 1)
                            Users
                        @else
                            User
                        @endif
                        @foreach($reliedUsers as $user)
                            <a href="{{ $user->link() }}">
                                    {{ $user->name }}@php echo ($reliedUsers->last() != $user) ? ', ' :  '';  @endphp
                                </a>
                        @endforeach
                        relies on the only group <strong>{{ $group->name }}</strong>.
                        Please relink
                        @if(count($reliedUsers) > 1)
                            them
                        @else
                            it
                        @endif
                        to some other group.
                    </span>
                </div>

            @else

                <div class="panel-body" style="padding: 28px;">

                    <div class="page-header text-center" style="margin-top: 0;">
                        <h3>Are you sure? <i class="em em-face_with_one_eyebrow_raised" style="font-size: large;"></i></h3>
                    </div>

                    <span class="pull-left" style="margin: .5em;">
                        <span class="text-muted">You cannot undo deletion of group {{ $group->name }}</span>
                    </span>
                    <span class="pull-right" style="margin: .5em;">
                        <form action="{{ route('groups.delete', ['group' => $group->id]) }}" method="post">
                            {{ method_field('DELETE') }}
                            {{ csrf_field() }}
                            <button class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span> Delete</button>
                        </form>
                    </span>
                    <span class="pull-right" style="margin: .5em;">
                        <a href="{{ $group->link() }}" class="btn btn-link btn-sm" style="margin-right: 1em;"><span class="glyphicon glyphicon-remove"></span> Cancel</a>
                    </span>

                </div>

            @endif


        </div>
    </div>
@endsection