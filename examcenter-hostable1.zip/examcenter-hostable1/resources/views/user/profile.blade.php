@extends('layouts.app')

@section('content')
    <div class="container" style="padding-bottom: 64px;">
        <div class="col-md-8 col-md-offset-2">

            <div class="panel panel-primary">
                <div class="panel-body" style="padding-bottom: 0">
                    <h4><p class="text-center"><strong>{{ $user->name }}</strong></p></h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Active Schedules
                        </div>
                        <div class="panel-body">
                            <ul class="list-group" style="margin-bottom: 0;">
                                @forelse($activeSchedules as $schedule)
                                    @if($schedule->isActive())
                                        <a class="list-group-item" href="{{ $schedule->link() }}"
                                           style="border: 0; @php echo (array_first($activeSchedules) == $schedule) ?: 'border-top: 1px solid #f5f5f5;'; @endphp">
                                            {{$schedule->name}}
                                            <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                        </a>
                                    @endif
                                @empty
                                    <li class="list-group-item text-muted" style="border: 0;">
                                        No schedules are active for now
                                    </li>
                                @endforelse
                            </ul>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Assigned Schedules
                        </div>
                        <div class="panel-body">
                            <ul class="list-group" style="margin-bottom: 0;">
                                @forelse($user->assignedSchedules as $schedule)
                                    <a class="list-group-item" href="{{ $schedule->link() }}"
                                       style="border: 0; @php echo ($user->assignedSchedules->first() == $schedule) ?: 'border-top: 1px solid #f5f5f5;'; @endphp">
                                        {{$schedule->name}}
                                        <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                    </a>
                                @empty
                                    <li class="list-group-item text-muted" style="border: 0;">
                                        No schedules are assigned
                                    </li>
                                @endforelse
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="panel panel-default">
                        <div class="panel-heading" style="display: inline-block; width: 100%;">
                        <span class="pull-left">
                        Details
                            </span>
                            <span class="pull-right">
                            <a class="btn btn-primary btn-xs" href="{{ route('edit_profile.view') }}"><span
                                        class="glyphicon glyphicon-pencil"></span> Edit Profile</a>
                        </span>
                        </div>
                        <div class="panel-body" style="padding-top: 0;">
                            <ul class="list-group" style="margin-bottom: 0;">
                                <li class="list-group-item" style="border: 0;">
                                    Email Id: <a href="mailto:{{ $user->email }}">{{ $user->email }}</a>
                                </li>
                                <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                    Created by: <a href="{{ $user->creator->link() }}">   <!--$group->creator->link()-->
                                        {{ $user->creator->name }}
                                    </a>
                                </li>
                                <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                    Created: {{ $user->created_at->diffForHumans() }}
                                </li>
                                <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                    Last updated: {{ $user->updated_at->diffForHumans() }}
                                </li>
                                <a href="{{route('change_password.view')}}" class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5; color:#a94442 !important;"> Change Password </a>

                            </ul>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Group List
                        </div>
                        <div class="panel-body">
                            <ul class="list-group" style="margin-bottom:0">
                                @forelse($user->groups as $group)
                                    <a class="list-group-item" href="{{ $group->link() }}"
                                       style="border: 0; @php echo ($user->groups->first() == $group) ?: 'border-top: 1px solid #f5f5f5;'; @endphp">
                                        {{$group->name}}
                                        <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                    </a>
                                @empty
                                    <li class="list-group-item text-muted" style="border: 0;">
                                        No groups are assigned
                                    </li>
                                @endforelse
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection