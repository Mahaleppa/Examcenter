@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5>All Users</h5>
                </span>
                <span class="pull-right category-modifiers">
                    <a href="{{ route('users.create') }}"
                       class="btn btn-link" style="vertical-align: middle; margin: .4em;" data-toggle="tooltip" title="Create User">
                        <span class="glyphicon glyphicon-plus"></span>
                    </a>
                </span>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                @forelse($users as $user)
                    <a class="list-group-item" href="{{ $user->link() }}"
                       style="border: 0;">
                        {{ $user->name }}
                        <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                    </a>
                @empty
                    <li class="list-group-item text-muted" style="border: 0;">
                        No users available
                    </li>
                @endforelse
            </div>
        </div>
    </div>
    </div>
@endsection
