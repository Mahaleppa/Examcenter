@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading" style="display: inline-block; width: 100%;">
                        <div class="pull-left">
                            Question {{ '@' }}{{ $question->id }}
                        </div>
                        <div class="pull-right">
                            <a href="#" class="btn btn-xs btn-danger" data-toggle="tooltip"
                               title="Delete Question">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </div>
                        <div class="pull-right">
                            <a class="btn btn-primary btn-xs" href="{{ $question->exam->link() }}"
                               style="margin-right: 1em;">Go to exam <span
                                        class="glyphicon glyphicon-chevron-right"></span></a>
                        </div>
                    </div>
                    <div class="panel-body" style="word-break: break-all;">
                        @markdown($question->description)
                    </div>
                    <div class="panel-footer">
                        <span>
                        <span class="glyphicon glyphicon-info-sign"></span>
                            @if($question->is_multi_answered)
                                This question has multiple correct answers
                            @else
                                This question has only one correct answer
                            @endif
                        </span>
                        <span class="text-muted" style="float: right;">
                            {{ $question->marks }} @php echo ($question->marks == 1) ?  'mark' : 'marks' @endphp
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-md-offset-2">

                <div class="row ">
                    @foreach($question->answers as $key => $answer)

                        <div class="col-md-8 col-md-offset-2">
                            <div class="panel @if($answer->is_correct_answer) panel-success @else panel-default @endif">
                                <div class="panel-heading" style="display: inline-block; width: 100%;">
                                    <div class="pull-left">
                                        Answer {{ $key+1 }}
                                    </div>
                                    <div class="pull-right">
                                        @if($answer->is_correct_answer)
                                            <span class="glyphicon glyphicon-ok" style="color: inherit;"
                                                  data-toggle="tooltip"
                                                  title="Correct Answer"></span>
                                        @endif
                                    </div>
                                </div>
                                <div class="panel-body">
                                    @markdown($answer->description)
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
@endsection
