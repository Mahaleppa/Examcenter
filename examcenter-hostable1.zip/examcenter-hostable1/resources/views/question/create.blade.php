@extends('layouts.app')

@section('content')
    <div class="container" style="margin-top: 1.5em; margin-bottom: 3em;">
        <div class="row">
            @if($errors->any())
                <div class="col-md-8 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-body alert alert-danger">
                            <ul>
                                @forelse($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @empty
                                @endforelse
                            </ul>
                        </div>
                    </div>
                </div>
            @endif
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-body">
                        Question belongs to <strong><a href="{{ $exam->link() }}">{{ $exam->name}}</a></strong>
                    </div>
                </div>
                <form action="{{ route('exams.questions.store', ['exam' => $exam->id]) }}" method="post">
                    <question-create-component csrf_token="{{ csrf_token() }}"><span class="text-muted">Loading...</span></question-create-component>
                </form>
            </div>
        </div>
    </div>

@endsection