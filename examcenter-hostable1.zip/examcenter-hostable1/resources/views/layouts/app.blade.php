<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link href="https://afeld.github.io/emoji-css/emoji.css" rel="stylesheet">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

    <style>
        body{
            background: #e2e2e2;
        }
        .glyphicon{
            line-height: 1.65em;
        }
    </style>
    <style>

    </style>


</head>
<body>
    <div id="app">
        <div class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="{{ url('/ ') }}">
                        {{ config('app.name', 'ExamCenter') }}
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                   	@if(Auth::check() && auth()->user()->isAdmin())
		                <li>
		                    <a href="{{ route('home') }}">Home</a>
		                </li>
		                <li>
		                    <a href="{{ route('exams') }}">Exams</a>
		                </li>
                            <li>
                                <a href="{{ route('schedules') }}">Schedules</a>
                            </li>
		                <li>
		                    <a href="{{ route('categories') }}">Categories</a>
		                </li>
		                <li>
		                    <a href="{{ route('groups') }}">Groups</a>
		                </li>
		                <li>
		                    <a href="{{ route('users') }}">Users</a>
		                </li>
	                @endif		
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        @guest
                            <li><a href="{{ route('login') }}">Login</a></li>
                        @else
                            <li>
                                <a href="{{route('profile')}}">
                                     <span class="glyphicon glyphicon-user"></span>
                                    {{ Auth::user()->name }}</>
                                </a>
                            </li>

                            <li>
                                <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" data-toggle="tooltip" title="Logout">
                                    <span class="glyphicon glyphicon-off text-danger"></span>
                                </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    {{ csrf_field() }}
                                </form>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    @foreach (['danger', 'warning', 'success', 'info'] as $key)
                        @if(Session::has($key))
                            <div class="alert alert-{{ $key }} alert-auto-dismiss alert-dismissable fade in" >
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! Session::get($key) !!}
                            </div>
                        @endif
                    @endforeach
                </div>
            </div>
        </div>

        <div style="margin-bottom: 5em;">
            @yield('content')
        </div>

    </div>
    <script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="{{ asset('js/app.js') }}"></script>
    @if(isset($endtime))
        <script>
            $(function(){
                $("#timer").countdowntimer({
                    dateAndTime : "{{ $endtime }}",
                    expiryUrl: "{{ route('schedule.solve_test.end', ['schedule' => $schedule->id]) }}"
                });
            });
        </script>
    @endif
</body>
</html>
