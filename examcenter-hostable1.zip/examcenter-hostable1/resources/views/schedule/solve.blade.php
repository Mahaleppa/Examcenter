@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3" style="padding: 0;">
                <div class="panel panel-info">
                    <div class="panel-heading" style="display: inline-block; width: 100%">
                        <div class="pull-left">
                            Navigation
                        </div>
                        <div class="pull-right label label-danger"
                             style="font-size: 11px; font-weight: bold !important;">
                            <span class="glyphicon glyphicon-time"></span>
                            <span id="timer">Initializing timer</span>
                        </div>
                    </div>
                    <div class="panel-body"
                         style="max-height: 200px; padding-top: 1em; padding-bottom: 1.8em; overflow-y: scroll;">
                        @foreach(range(1, $questions->total()) as $iter)
                            <div class="col-xs-2" style="margin: .3em;">
                                <a href="{{ $questions->url($iter) }}"
                                   class="btn btn-@php echo ($questions->currentPage() == $iter) ? 'primary' : ' default' @endphp">{{ $iter }}</a>
                            </div>
                        @endforeach
                    </div>
                    <div class="panel-footer" style="display: inline-block; width: 100%; height: 4em;">
                        @if($questions->currentPage() != 1)
                            <a class="btn btn-default btn-sm pull-left" href="{{ $questions->previousPageUrl() }}"><span
                                        class="glyphicon glyphicon-chevron-left"></span> Previous</a>
                        @endif
                        @if($questions->currentPage() != $questions->lastPage())
                            <a class="btn btn-default btn-sm pull-right" href="{{ $questions->nextPageUrl() }}">Next
                                <span
                                        class="glyphicon glyphicon-chevron-right"></span></a>
                        @endif
                    </div>
                    <div class="panel-footer">
                        <a href="{{ route('schedule.solve_test.end', ['schedule' => $schedule->id]) }}" class="btn btn-warning btn-block">End Test</a>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row">

                    <div class="col-md-10 col-md-offset-1">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                Description
                            </div>
                            <div class="panel-body" style="word-break: break-all;">
                                @markdown($currentQuestion->description)
                            </div>
                            <div class="panel-footer" style="height: 3.3em;">
                                <span class="text-muted" style="position: relative;float: right;">
                                    {{ $currentQuestion->marks }} @php echo ($currentQuestion->marks == 1) ? 'mark' : 'marks' @endphp
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            @foreach($currentQuestion->answers as $answer)
                                <schedule-test-answer-component answer_id="{{ $answer->id }}"
                                                                answer_description="{{ $answer->description }}"
                                                                is_multi_answered="{{ $currentQuestion->is_multi_answered }}"
                                                                answer_checked="@php echo ($answers != null && array_search($answer->id, $answers) !== false) ? true : false @endphp"
                                                                answer_submit_route="{{ route('schedule.solve_test.submit_answer', ['schedule' => $schedule->id]) }}">
                                    <div class="col-md-8 col-md-offset-2">
                                        <div class="panel panel-default">
                                            <div class="panel-body">
                                                <span class="text-muted">Loading Answer...</span>
                                            </div>
                                        </div>
                                    </div>
                                </schedule-test-answer-component>
                            @endforeach
                        </div>
                        <div class="col-md-8 col-md-offset-2" style="padding-right: .4em; margin-top: 1em;">
                            <div class="pull-right">
                                @if($questions->currentPage() != 1)
                                    <a class="btn btn-default" href="{{ $questions->previousPageUrl() }}"
                                       style="margin-right 0;margin-left: 1em;"><span
                                                class="glyphicon glyphicon-chevron-left"></span> Previous</a>
                                @endif
                                @if($questions->currentPage() != $questions->lastPage())
                                    <a class="btn btn-primary" href="{{ $questions->nextPageUrl() }}"
                                       style="margin-left: 1em;">Next <span
                                                class="glyphicon glyphicon-chevron-right"></span></a>
                                @else
                                    <a class="btn btn-warning" href="{{ route('schedule.solve_test.end', ['schedule' => $schedule->id]) }}" style="margin-left: 1em;">End Test <span
                                                class="glyphicon glyphicon-ok-sign"></span></a>
                                @endif
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection