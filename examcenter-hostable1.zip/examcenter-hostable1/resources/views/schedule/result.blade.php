<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="{{ public_path('css/app.css') }}" rel="stylesheet" type="text/css" media="all">
</head>

<body>

    <div class="container" style="padding-top: 1em;">
        <div class="panel panel-default">
            <div class="panel-body" style="padding: 28px;">
                <h6 class="text-muted pull-right" style="padding: 9px;">{{ config('app.name') }}</h6>
                <h4 class="">Result</h4>
                <hr>
                <div class="row"></div>
                <p class="col-xs-6" style="line-height: 2.4;">
                    <span class="col-xs-5">
                        <span><strong>Schedule name:</strong></span>
                        <br>
                        <span><strong>Commenced at:</strong></span>
                        <br>
                        <span><strong>Finished at:</strong></span>
                    </span>
                    <span class="col-xs-7">
                        <span>{{$schedule->name}}</span>
                        <br>
                        <span>{{$schedule->commenced_at->format('D, d M Y, h:i a')}}</span>
                        <br>
                        <span>{{$schedule->finished_at->format('D, d M Y, h:i a')}}</span>
                    </span>

                </p>
                <p class="col-xs-6" style="line-height: 2.4;">
                    <span class="col-xs-5">
                        <span><strong>Time Span:</strong></span>
                        <br>
                        <span><strong>Total Marks:</strong></span>
                        <br>
                        <span><strong>Created By:</strong></span>
                        <br>
                        </span>
                        <span class="col-xs-7">
                            <span>
                                @php
                                    $time = Carbon\Carbon::createFromFormat('H:i', $schedule->time_span);
                                    echo $time->hour . ' ' . (($time->hour == 1) ? 'hour' : 'hours') ;
                                    echo ', ';
                                    echo $time->minute . ' ' . (($time->minute == 1) ? 'minute' : 'minutes');
                                @endphp
                        </span>
                        <br>
                        <span>{{$scheduleMarks}}</span>
                        <br>
                        <span>{{$schedule->creator->name}}</span>
                        <br>
                    </span>
                </p>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($schedule->assignedUsers as $key=>$user)
                            <tr>
                                <td>{{ $key+1 }}</td>
                                <td>{{ $user->name }}</td>
                                <td>
                                    @if($user->pivot->commenced_at == null || $user->pivot->finished_at == null)
                                        AB
                                    @else
                                        {{ $user->pivot->score }}
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
