@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
            @if($errors->any())
                    <div class="panel panel-default">
                        <div class="panel-body alert alert-danger">
                            <ul>
                                @forelse($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @empty
                                @endforelse
                            </ul>
                        </div>
                    </div>
        @endif
        {!! Form::open(['url' => route('exams.schedules.store', ['exam' => $exam->id])]) !!}
                    <div class="panel panel-default">
                    <div class="panel-body">
                        Scheduling exam <strong><a href="{{ $exam->link() }}">{{ $exam->name }}</a></strong>
                    </div>
                    </div>

                    <div class="panel panel-primary">
                    <div class="panel-heading">
                        Schedule Details
                    </div>
                    <div class="panel-body" style="padding: 28px;">
                        <div class="form-group">
                            {!! Form::text('name', null, ['placeholder' => 'Name', 'class' => 'form-control']) !!}
                        </div>

                        <div class="form-group">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                            Description
                        </div>
                        <div class="panel-body">
                            <schedule-description-component><span class="text-muted">Loading...</span>
                            </schedule-description-component>
                        </div>
                        </div>
                </div>
                <div class="form-group">
                    {!! Form::label('time_span', 'Time span for exam (hh:mm)', ['class' => 'control-label']) !!}
                    {!! Form::text('time_span', null,['placeholder' => 'hh:mm', 'class' => 'form-control']) !!}
                </div>
            </div>
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading">
                Questions Allotment
            </div>
            <div class="panel-body" style="padding: 28px;">
                @foreach($marksOfQuestion as $mark)
                    <div class="form-group row"
                         style="@php ($marksOfQuestion->last() == $mark) ?: 'margin-bottom: 2em;' @endphp">
                        {!! Form::label("marks[$mark->marks]", "$mark->marks " . (($mark->marks == '1') ? "mark" : "marks"), ['class' => 'col-md-2 control-label', 'style' => 'line-height: 2.9;']) !!}
                        <div class="col-md-10">
                            {!! Form::select("marks[$mark->marks]",range(0, $mark->total), null, ['class' => 'form-control']) !!}
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
        <div class="panel panel-primary">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Groups to be assigned to schedule
                </div>
                <div class="panel-body" style="padding: 32px;">
                    <ul class="list-group" style="margin-bottom: 0;">
                        @forelse($groups as $group)
                            <li class="list-group-item col-md-6" style="border: 0;">
                                {!! Form::checkbox('groups[]', $group->id, null, ['id' => $group->id]) !!}
                                {!! Form::label($group->id, $group->name, ['class' => 'control-label']) !!}
                            </li>
                        @empty
                            <li class="list-group-item col-md-6 text-muted" style="border: 0;">
                                No groups avail in this category
                            </li>
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>
        {!! Form::submit('Create Schedule', ['class' => 'btn btn-primary']) !!}
        {!! Form::close() !!}
                </div>
            </div>
    </div>

@endsection