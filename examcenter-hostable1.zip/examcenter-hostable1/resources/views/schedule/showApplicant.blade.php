@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5><span class="text-muted">Schedule: </span>{{ $schedule->name }}</h5>
                </span>
                <span class="pull-right category-modifiers" style="margin: .7em;">
                    @if($schedule->isCommenced())
                        @if($user->pivot->commenced_at == null)
                            <a href="{{ route('schedule.apply_test', ['schedule' => $schedule->id]) }}"
                               class="btn btn-primary btn-sm" style="margin-right: 1em;" data-toggle="tooltip"
                               title="Commence Exam">
                            <span class="glyphicon glyphicon-send"></span>
                        </a>
                        @elseif($user->pivot->finished_at == null)
                            <a href="{{ route('schedule.solve_test', ['schedule' => $schedule->id]) }}"
                               class="btn btn-primary btn-sm" style="margin-right: 1em;" data-toggle="tooltip"
                               title="Show Test Page">
                            <span class="glyphicon glyphicon-paste"></span>
                        </a>
                        @endif
                    @endif
                </span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <div class="panel panel-default ">
                    <div class="panel-heading" style="display: inline-block; width: 100%;">
                        Schedule Description
                    </div>
                    <div class="panel-body" style="padding: 28px;">
                        @markdown($schedule->description)
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="panel panel-default ">
                    <div class="panel-heading">
                        Question Preferences
                    </div>
                    <div class="panel-body">
                        <ul class="list-group" style="margin-bottom: 0;">
                            @forelse($schedule->questions_count as $mark=>$amount)
                                <li class="list-group-item"
                                    style="border: 0; @php echo (array_first($schedule->questions_count) == $amount) ?: 'border-top: 1px solid #f5f5f5;'; @endphp">
                                    <strong>{{ $mark }}</strong> @if($mark == 1) mark @else marks @endif:
                                    <strong>{{ $amount }}</strong> @if($amount == 1) question @else questions @endif
                                </li>
                            @empty
                                <li class="list-group-item text-muted" style="border: 0;">No question allotted</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Schedule Details
                    </div>
                    <div class="panel-body">
                        <ul class="list-group" style="margin-bottom: 0;">
                            <li class="list-group-item" style="border: 0;">
                                Created by: <a href="{{ $schedule->creator->link() }}">
                                    {{ $schedule->creator->name }}
                                </a>
                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Created: {{ $schedule->created_at->diffForHumans() }}
                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Last updated: {{ $schedule->updated_at->diffForHumans() }}
                            </li>
                            @if($schedule->isCommenced())
                                <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                    Commenced: {{ $schedule->created_at->diffForHumans() }}
                                </li>
                            @endif
                            @if($schedule->isFinished())
                                <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                    Finished: {{ $schedule->created_at->diffForHumans() }}
                                </li>
                            @endif
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Status: @if($schedule->isActive()) <span class="text-success">Active</span> @else <span
                                        class="text-danger">Inactive</span> @endif
                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection