@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5>All Schedules</h5>
                </span>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-body" style="padding-left: 28px;">
                    @forelse($schedules as $schedule)
                        <a class="list-group-item" href="{{ $schedule->link() }}"
                           style="border: 0; @php echo ($schedules->first() == $schedule) ?: 'border-top: 1px solid #f5f5f5;'; @endphp">
                            {{ $schedule->name }}
                            <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                        </a>
                    @empty
                        <li class="list-group-item text-muted" style="border: 0;">
                            No schedules available
                        </li>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
@endsection
