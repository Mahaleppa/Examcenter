<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <title>Exam Scheduled</title>
</head>
<style>
    body {
        background: #e2e2e2;
    }
</style>
<body >
<div class="container" style="padding: 2em;">
    <div class="panel panel-default">
        <div class="panel-body">
            <h5>Hello {{ $user->name }},</h5>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-body alert alert-success">
            You have been assigned a new exam schedule.
        </div>
    </div>
    <div class="panel panel-info">
        <div class="panel-heading" style="display: inline-block; width: 100%;">
            <div class="pull-left">
                Schedule Description
            </div>
            <div class="pull-right">
                <a class="btn btn-xs btn-primary" href="{{ $schedule->link() }}">Go to schedule <span class="glyphicon glyphicon-chevron-right"></span></a>
            </div>
        </div>
        <div class="panel-body">
            <h6>{{ $schedule->name }}</h6>
            <hr>
            @markdown($schedule->description)
        </div>
    </div>
</div>
</body>
</html>