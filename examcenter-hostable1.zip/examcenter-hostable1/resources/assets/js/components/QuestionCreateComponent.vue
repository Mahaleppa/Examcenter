<template>
    <div>
        <input type="hidden" name="_token" :value="csrf_token">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Question Description
            </div>
            <div class="panel-body">
                <markdown-editor :options="options" :toolbar="toolbar" name="description" v-model="value" placeholder="Description"></markdown-editor>
            </div>
            <div class="panel-body" style="border-top: 1px solid #e2e2e2; border-bottom: 1px solid #e2e2e2;">
                <span class="text-muted">Preview: </span>
                <hr style="margin-top: 1em;">
                <div class="panel-body" v-html="compiledMarkdown" style="word-break: break-word;"></div>
            </div>
            <div class="panel-footer">
                <input type="checkbox" name="isMultiAnswered" id="isMultiAnswered" v-model="isMultiAnswered"/>
                <label for="isMultiAnswered" class="control-label">Does this question have multiple answers?</label>
            </div>
            <div class="panel-footer" style="display: inline-flex; width: 100%;">
                <input type="number" class="form-control" style="width:auto; margin: 0;" name="marks" id="marks"/>
                <label for="marks" style="padding: .7em;">Marks</label>
            </div>
        </div>
        <answer-create-component v-for="(answerInstance, index) in answerInstances" :is-multi-answered="isMultiAnswered"
                                 :answer-data="answerInstance.data" :answer-number="index+1" :key="answerInstance.id"
                                 v-on:deleteMe="removeAnswerInstance(index)"><span class="text-muted">Loading...</span></answer-create-component>
        <button class="btn btn-sm btn-info" @click.prevent="addAnswerInstance">
            <span class="glyphicon glyphicon-plus-sign"></span>
            Add new answer
        </button>
        <hr style="color: #ccc; background-color: #ccc; border-color: #ccc;"/>
        <input type="hidden" name="answerCount" :value="answerCount"/>
        <button type="submit" class="btn btn-primary" style="float: right;" :disabled="answerCount < 2 || !value">Save</button>
    </div>
</template>

<script>
    import Editor from 'v-markdown-editor'
    import marked from 'marked'
    import AnswerCreateComponent from './AnswerCreateComponent.vue'

    export default {
        name: "question-component",
        props: ['csrf_token'],
        components: {
            Editor,
            AnswerCreateComponent
        },
        data() {
            return {
                // default options, see more options at: http://codemirror.net/doc/manual.html#config
                options: {
                    lineNumbers: true,
                    styleActiveLine: true,
                    styleSelectedText: true,
                    lineWrapping: true,
                    indentWithTabs: true,
                    tabSize: 2,
                    indentUnit: 2,
                    smartIndent: true
                },
                toolbar: "bold italic heading image link numlist bullist code",
                value: "",
                answerInstances: [],
                isMultiAnswered: false,
                nextAnswerId: 0
            }
        },
        computed: {
            compiledMarkdown: function () {
                return marked(this.value, {sanitize: true});
            },
            answerCount() {
                return this.answerInstances.length
            }
        },
        methods: {
            addAnswerInstance() {
                this.answerInstances.push({'id': this.nextAnswerId++, data: ''});
            },
            removeAnswerInstance(index) {
                this.$delete(this.answerInstances, index)
            }
        }
    }
</script>

<style>
    .v-md-toolbar {
        height: auto !important;
    }

    button.btn-outline-secondary {
        margin: .3em !important;
    }
</style>