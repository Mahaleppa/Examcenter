<template>
    <div class="form-group">
        <markdown-editor :options="options" :toolbar="toolbar" name="description" v-model="value"></markdown-editor>
        <div class="panel-body">
            <span class="text-muted">Preview:</span>
            <hr style="margin-top: 1em;">
            <div class="panel-body" v-html="compiledMarkdown" style="word-break: break-word;"></div>
        </div>
    </div>
</template>
<script>
    import Editor from 'v-markdown-editor'
    import marked from 'marked'

    export default {
        name: 'schedule-description-component',
        components: {
            Editor
        },
        data() {
            return {
                options: {
                    lineNumbers: true,
                    styleActiveLine: true,
                    styleSelectedText: true,
                    lineWrapping: true,
                    indentWithTabs: true,
                    tabSize: 2,
                    indentUnit: 2,
                    smartIndent: true
                },
                toolbar: "bold italic heading link numlist bullist code",
                value: "",
            }
        },
        computed: {
            compiledMarkdown: function () {
                return marked(this.value, {sanitize: true});
            }
        }
    }
</script>