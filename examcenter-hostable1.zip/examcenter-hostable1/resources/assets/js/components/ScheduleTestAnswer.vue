<template>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="row">
                    <div class="col-xs-1">
                        <input v-if="is_multi_answered_computed" type="checkbox" class="checkbox-inline" v-model="answer_checked_computed"
                               style="margin: 0;" name="answer[]" value="1"/>
                        <input v-else type="radio" class="radio-inline"
                               v-model="answer_checked_computed" name="answer" value="1"/>
                    </div>
                    <div class="col-xs-11" v-html="compiledMarkdown"><span class="text-muted">Loading Answer...</span></div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import marked from 'marked'

    export default{
        name: "schedule-test-answer-component",
        props: ['answer_description', 'answer_checked', 'answer_id', 'answer_submit_route', 'is_multi_answered'],
        computed: {
            compiledMarkdown: function () {
                return marked(this.description, {sanitize: true});
            },
            description: function () {
                return this.answer_description;
            },
            answer_submit_route_computed: function (){
                return this.answer_submit_route;
            },
            answer_id_computed: function () {
                return this.answer_id;
            },
            is_multi_answered_computed: function () {
                return (this.is_multi_answered > 0);
            },
            answer_checked_computed: {
                get() {
                    return this.answer_checked
                },
                set(){
                    axios.post(this.answer_submit_route_computed, {
                        answer_id: this.answer_id_computed,
                    })
                        .catch(function (error) {
                            window.location.href = "/home"
                        })
                }
            },
        }
    }
</script>