<template>
    <div class="panel panel-default">
        <div class="panel-heading">
            <span>
                Answer #{{answerNumber}}
            </span>
            <span style="float: right;">
                <button class="btn btn-xs btn-danger" @click.prevent="sendRemoveRequest">
                    <span class="glyphicon glyphicon-remove"></span>
                </button>
            </span>
        </div>
        <div class="panel-body">
            <markdown-editor :options="options" :toolbar="toolbar" :name="'answer_'+answerNumber+'_description'" v-model="value"></markdown-editor>
        </div>
        <div class="panel-body" style="border-top: 1px solid #e2e2e2; border-bottom: 1px solid #e2e2e2;">
            <span class="text-muted">Preview: </span>
            <hr style="margin-top: 1em;">
            <div class="panel-body" v-html="compiledMarkdown" style="word-break: break-word;"></div>
        </div>
        <div class="panel-footer">
            <input :type="isMultiAnswered ? 'checkbox' : 'radio'" :name="isMultiAnswered ? 'answer_correct[]' : 'answer_correct'" :value="answerNumber" :id="'answer_'+answerNumber+'_correct'">
            <label :for="'answer_'+answerNumber+'_correct'">Is this the correct answer?</label>
        </div>

    </div>
</template>

<script>
    import Editor from 'v-markdown-editor'
    import marked from 'marked'

    export default {
        props: ['answerNumber', 'answerData', 'isMultiAnswered'],
        name: "answer-create-component",
        components: {
            Editor
        },
        created: function () {
            this.value = this.answerData
        },
        data () {
            return {
                options: {
                    lineNumbers: true,
                    styleActiveLine: true,
                    styleSelectedText: true,
                    lineWrapping: true,
                    indentWithTabs: true,
                    tabSize: 2,
                    indentUnit: 2,
                    smartIndent: true
                },
                toolbar: "bold italic heading image link numlist bullist code",
                answer: ''
            }
        },
        computed: {
            compiledMarkdown: function () {
                return marked(this.value, {sanitize: true});
            },
            value: {

                get: function () {
                    return this.answer;
                },

                set: function (val) {
                    this.answer = val;

                }
            }
        },
        methods: {
            sendRemoveRequest () {
                this.$emit('deleteMe');
            }
        }
    }
</script>

<style scoped>

</style>