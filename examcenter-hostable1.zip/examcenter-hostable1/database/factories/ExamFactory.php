<?php

use Faker\Generator as Faker;

$factory->define(\App\Exam::class, function (Faker $faker) {
    return [
        'name' => $faker->word,
        'user_id' => \App\User::first()
    ];
});
