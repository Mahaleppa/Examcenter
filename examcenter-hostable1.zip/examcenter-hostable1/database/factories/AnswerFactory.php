<?php

use Faker\Generator as Faker;

$factory->define(\App\Answer::class, function (Faker $faker) {
    return [
        'description' => $faker->paragraph,
        'is_correct_answer' => false,
        'question_id' => \App\Question::first()
    ];
});
