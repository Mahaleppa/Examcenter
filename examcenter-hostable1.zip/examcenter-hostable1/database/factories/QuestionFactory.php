<?php

use Faker\Generator as Faker;

$factory->define(\App\Question::class, function (Faker $faker) {
    return [
        'description' => $faker->paragraph,
        'marks' => rand(1, 5),
        'exam_id' => \App\Exam::first(),
        'user_id' => \App\User::first()
    ];
});
