<?php

use Illuminate\Database\Seeder;

class AnswersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Answer::class, 3)->create();
        factory(\App\Answer::class, 1)->create(['is_correct_answer' => true]);
    }
}
