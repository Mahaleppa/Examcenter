<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

if (config('app.debug')){
    Route::get('/users/first', 'HomeController@firstUserView')->name('users.first.view')->middleware([]);
    Route::post('/users/first', 'HomeController@firstUserStore')->name('users.first.store')->middleware([]);
}

Route::get('/home', 'HomeController@index')->name('home')->middleware(['auth']);
Route::get('users','UserController@index')->name('users')->middleware(['auth', 'admin']);
Route::get('/users/create', 'UserController@create')->name('users.create')->middleware(['auth', 'admin']);
Route::post('/users/create', 'UserController@store')->name('users.store')->middleware(['auth', 'admin']);
Route::get('/users/{user}', 'UserController@show')->name('users.show')->middleware(['auth', 'admin']);

Route::get('/edit/profile','UserController@editProfileView')->name('edit_profile.view')->middleware(['auth']);
Route::post('/edit/profile','UserController@editProfile')->name('edit_profile')->middleware(['auth']);
Route::get('/profile', 'UserController@profile')->name('profile')->middleware(['auth']);
Route::get('/change_password', 'UserController@changePasswordView')->name('change_password.view')->middleware(['auth']);
Route::post('/change_password', 'UserController@changePassword')->name('change_password')->middleware(['auth']);

Route::get('categories', 'CategoryController@index')->name('categories')->middleware(['auth', 'admin']);
Route::post('categories','CategoryController@store')->name('categories.store')->middleware(['auth', 'admin']);
Route::get('categories/create','CategoryController@create')->name('categories.create')->middleware(['auth', 'admin']);
Route::get('categories/{category}/edit/name', 'CategoryController@updateNameView')->name('categories.edit.name.view')->middleware(['auth', 'admin']);
Route::put('categories/{category}/name', 'CategoryController@updateName')->name('categories.edit.name')->middleware(['auth', 'admin']);
Route::get('categories/{category}/edit/groups', 'CategoryController@updateGroupsView')->name('categories.edit.groups.view')->middleware(['auth', 'admin']);
Route::put('categories/{category}/groups', 'CategoryController@updateGroups')->name('categories.edit.groups.store')->middleware(['auth', 'admin']);
Route::delete('categories/{category}/groups', 'CategoryController@removeGroups')->name('categories.edit.groups.remove')->middleware(['auth', 'admin']);
Route::get('categories/{category}/delete', 'CategoryController@deleteView')->name('categories.delete.view')->middleware(['auth', 'admin']);
Route::get('categories/{category}', 'CategoryController@show')->name('categories.show')->middleware(['auth', 'admin']);
Route::delete('categories/{category}', 'CategoryController@delete')->name('categories.delete')->middleware(['auth', 'admin']);

Route::get('groups', 'GroupController@index')->name('groups')->middleware(['auth', 'admin']);
Route::get('/groups/create', 'GroupController@create')->name('groups.create')->middleware(['auth', 'admin']);
Route::post('/groups/create', 'GroupController@store')->name('groups.store')->middleware(['auth', 'admin']);
Route::get('groups/{group}/edit/name', 'GroupController@updateNameView')->name('groups.edit.name.view')->middleware(['auth', 'admin']);
Route::put('groups/{group}/name', 'GroupController@updateName')->name('groups.edit.name')->middleware(['auth', 'admin']);
Route::get('groups/{group}/delete', 'GroupController@deleteView')->name('groups.delete.view')->middleware(['auth', 'admin']);
Route::get('groups/{group}', 'GroupController@show')->name('groups.show')->middleware(['auth', 'admin']);
Route::delete('groups/{group}', 'GroupController@delete')->name('groups.delete')->middleware(['auth', 'admin']);

Route::get('exams', 'ExamController@index')->name('exams')->middleware(['auth', 'admin']);
Route::post('exams','ExamController@store')->name('exams.store')->middleware(['auth', 'admin']);
Route::get('exams/create','ExamController@create')->name('exams.create')->middleware(['auth', 'admin']);
Route::get('exams/{exam}/edit', 'ExamController@updateView')->name('exams.edit.view')->middleware(['auth', 'admin']);
Route::get('exams/{exam}/delete', 'ExamController@deleteView')->name('exams.delete.view')->middleware(['auth', 'admin']);
Route::get('exams/{exam}/questions/create', 'ExamController@createQuestionView')->name('exams.questions.create')->middleware(['auth', 'admin']);
Route::post('exams/{exam}/questions', 'ExamController@createQuestion')->name('exams.questions.store')->middleware(['auth', 'admin']);
Route::get('exams/{exam}/schedules/create', 'ExamController@createScheduleView')->name('exams.schedules.create')->middleware(['auth', 'admin']);
Route::post('exams/{exam}/schedules', 'ExamController@createSchedule')->name('exams.schedules.store')->middleware(['auth', 'admin']);
Route::put('exams/{exam}', 'ExamController@update')->name('exams.edit')->middleware(['auth', 'admin']);
Route::get('exams/{exam}', 'ExamController@show')->name('exams.show')->middleware(['auth', 'admin']);
Route::delete('exams/{exam}', 'ExamController@delete')->name('exams.delete')->middleware(['auth', 'admin']);

Route::get('question/{question}', 'QuestionController@show')->name('questions.show')->middleware(['auth', 'admin']);

Route::get('schedules','ExamScheduleController@index')->name('schedules')->middleware(['auth','admin']);
Route::get('schedule/{schedule}/solve_test', 'ExamScheduleController@solveTest')->name('schedule.solve_test')->middleware(['auth']);
Route::get('schedule/{schedule}/solve_test/end', 'ExamScheduleController@endTestAttempt')->name('schedule.solve_test.end')->middleware(['auth']);
Route::post('schedule/{schedule}/solve_test', 'ExamScheduleController@submitAnswer')->name('schedule.solve_test.submit_answer')->middleware(['auth']);
Route::get('schedule/{schedule}/apply_test', 'ExamScheduleController@applyTest')->name('schedule.apply_test')->middleware(['auth']);
Route::get('schedule/{schedule}/commence_test', 'ExamScheduleController@commenceTest')->name('schedule.commence_test')->middleware(['auth', 'admin']);
Route::get('schedule/{schedule}/finish_test', 'ExamScheduleController@finishTest')->name('schedule.finish_test')->middleware(['auth', 'admin']);
Route::get('schedule/{schedule}/result', 'ExamScheduleController@getResult')->name('schedule.result')->middleware(['auth', 'admin']);
Route::get('schedule/{schedule}', 'ExamScheduleController@show')->name('schedule.show')->middleware(['auth']);