<?php

namespace App;

use App\Helpers\UuidGen;
use Emadadly\LaravelUuid\Uuids;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Answer
 *
 * @mixin \Eloquent
 * @property int $id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Answer whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Answer whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Answer whereUpdatedAt($value)
 */
class Answer extends Model
{
    use Uuids;

    public $incrementing = false;

    protected $fillable = ['id', 'description', 'is_correct_answer', 'question_id'];

    public function question(){
        return $this->belongsTo(Question::class);
    }
}
