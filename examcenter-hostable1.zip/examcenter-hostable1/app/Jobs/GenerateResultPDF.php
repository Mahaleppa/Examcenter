<?php

namespace App\Jobs;

use App\ExamSchedule;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Storage;

class GenerateResultPDF implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $schedule;

    /**
     * Create a new job instance.
     *
     * @param ExamSchedule $schedule
     */
    public function __construct(ExamSchedule $schedule)
    {
        $this->schedule = $schedule;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $schedule = $this->schedule;

        $scheduleMarks = 0;
        foreach ($schedule->questions_count as $mark=>$amount){
            $scheduleMarks += ($mark*$amount);
        }

        $fileName = "{$schedule->id}_result.pdf";
        $pdf = \PDF::loadView('schedule.result', compact('schedule', 'scheduleMarks'));
        Storage::put($fileName, $pdf->output());

        $schedule->generatedPDF = true;
        $schedule->save();
    }

}
