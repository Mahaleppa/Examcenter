<?php

namespace App\Events;

use App\Exam;
use App\ExamSchedule;
use App\Group;
use App\ScheduleAssignment;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Http\Request;
use Illuminate\Queue\SerializesModels;

class ExamScheduled
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $examSchedule;

    /**
     * Create a new event instance.
     *
     * @param Exam $exam
     * @param ExamSchedule $schedule
     */
    public function __construct(Exam $exam, ExamSchedule $schedule, Request $request)
    {
        $this->examSchedule = $schedule;
        foreach ($request->input('groups') as $group) {
            $group = Group::find($group);
            foreach ($group->users as $user) {
                if ($user->assignedSchedules()->find($schedule->id) == null)
                    $user->assignedSchedules()->attach($schedule->id, ['id' => ScheduleAssignment::generateId()]);
            }
        }
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
