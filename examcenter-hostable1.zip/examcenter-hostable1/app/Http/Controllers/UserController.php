<?php

namespace App\Http\Controllers;

use App\Category;
use App\ExamSchedule;
use App\Group;
use App\RoleAssignment;
use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{

    public function index()
    {
        $users = User::orderBy('name')->get();
        return view('user.index',compact('users'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create(){
        $groups = Group::orderBy('name')->get();
        return view('user.create', compact('groups'));
    }

    /**
     * @param Request $request
     */
    public function store(Request $request){
        $this->validate($request, [
            'name' => 'required|regex:/[a-zA-Z] [a-zA-z]+/',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8|confirmed',
            'groups' => 'required|array|min:1',
            'groups.*' => 'exists:groups,id'
        ]);

        /** @var User $user */
        $user = auth()->user()->createdUsers()->create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => app('hash')->make($request->input('password')),
        ]);

        foreach($request->input('groups') as $groupId){
            $user->groups()->attach($groupId, ['relation_from_id' => $user->id,
                'relation_from_type' => User::class,
                'relation_to_type' => Group::class,
                'user_id' => auth()->id()
            ]);
        }
        return redirect(
            route(
                'users.show',
                [
                    'user' => $user->id
                ]
            )
        );
    }

    public function show(User $user)
    {
        $user->load(['groups','creator']);

        $activeSchedules = [];

        $user->assignedSchedules->each(
            function (ExamSchedule $schedule) use (&$activeSchedules, $user) {
            if($schedule->isActive() && $schedule->assignedUsers()->find($user->id)->pivot->finished_at == null)
                array_push($activeSchedules, $schedule);
        });
        return view('user.show', compact('user', 'activeSchedules'));
    }

    public function editProfileView()
    {
        /** @var User $user */
        $user = auth()->user();
        # $user->load(['name','email']);
        return view('user.editProfile', compact('user'));
    }

    public function profile()
    {
        /** @var User $user */
        $user = auth()->user();
        $user->load('groups');

        $activeSchedules = [];

        $user->assignedSchedules->each(
            function (ExamSchedule $schedule) use (&$activeSchedules, $user) {
                if ($schedule->isActive() && $schedule->assignedUsers()->find($user->id)->pivot->finished_at == null)
                    array_push($activeSchedules, $schedule);
            });
        return view('user.profile',compact('user', 'activeSchedules'));
    }

    public function editProfile(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|regex:[a-zA-Z][a-zA-z]+',
            'email' => 'required|email'
        ]);

        if(auth()->user()->email != $request->input('email'))
            $this->validate($request, [
                'email' => 'unique:users,email'
            ]);


        /** @var User $user */
        $user = auth()->user();
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->save();

        $request->session()->flash('success', 'Profile edited successfully');

        return redirect(route('profile'));
    }

    public function changePasswordView()
    {
        return view('user.changePassword');
    }

    public function changePassword(Request $request)
    {
        $this->validate($request, [
            'password' => 'required|min:8|confirmed',
        ]);

        /** @var User $user */
        $user = auth()->user();
        $user->password = app('hash')->make($request->input('password'));
        $user->save();

        $request->session()->flash('success', 'Password changed successfully');

        return redirect(route('profile'));
    }


}
