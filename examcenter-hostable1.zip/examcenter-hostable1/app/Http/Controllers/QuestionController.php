<?php

namespace App\Http\Controllers;

use App\Question;
use Illuminate\Http\Request;

class QuestionController extends Controller
{
    public function show(Question $question){
        $question->load(['exam', 'answers']);
        return view('question.show', compact('question'));
    }
}
