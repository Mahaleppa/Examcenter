<?php

namespace App\Http\Controllers;

use App\Category;
use App\Group;
use App\User;
use Illuminate\Http\Request;

class HomeController extends Controller
{

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function firstUserView()
    {
        return view('firstUser');
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function firstUserStore(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|regex:[a-zA-Z][a-zA-z]+',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8|confirmed',
            'category_name' => 'required|alpha_num',
            'group_name' => 'required|alpha_num',
        ]);

        /** @var User $user */
        $user = User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => app('hash')->make($request->input('password')),
        ]);

        $user->user_id = $user->id;
        $user->save();

        /** @var Group $group */
        $group = $user->createdGroups()->create([
            'name' => $request->input('group_name'),
            'is_admin' => true
        ]);

        $group->users()->attach($user->id, ['user_id' => $user->id, 'relation_to_type' => Group::class, 'relation_from_type' => User::class]);

        /** @var Category $category */
        $category = $user->createdCategories()->create([
            'name' => $request->input('category_name')
        ]);

        $category->groups()->attach($group->id, ['user_id' => $user->id, 'relation_to_type' => Category::class, 'relation_from_type' => Group::class]);

        return redirect(route('login'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
}
