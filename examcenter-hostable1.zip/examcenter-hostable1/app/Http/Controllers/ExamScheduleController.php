<?php

namespace App\Http\Controllers;

use App\Answer;
use App\ExamSchedule;
use App\Jobs\GenerateResultPDF;
use App\Question;
use Carbon\Carbon;
use Illuminate\Http\Request;
use PDF;
use Storage;
use Symfony\Component\HttpFoundation\Response;

class ExamScheduleController extends Controller
{

    /**
     * @param ExamSchedule $schedule
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */

    public function index()
    {
        $schedules = ExamSchedule::orderBy('name')->get();
        return view('schedule.index', compact('schedules'));
    }

    public function show(ExamSchedule $schedule)
    {
        $schedule->load(['assignedUsers']);
        if (auth()->id() === $schedule->creator->id) {
            $schedule->load(['creator', 'exam']);
            return view('schedule.showTeacher', compact('schedule'));
        } else {
            $user = $schedule->assignedUsers()->find(auth()->id());
            if ($user != null) {
                return view('schedule.showApplicant', compact('schedule', 'user'));
            }
            abort(Response::HTTP_NOT_FOUND);
        }
    }

    public function commenceTest(ExamSchedule $schedule)
    {
        if($schedule->isFinished() || $schedule->isActive())
            abort(Response::HTTP_NOT_FOUND);

        if (!$schedule->isCommenced()) {
            $schedule->commenced_at = Carbon::now();
            $schedule->load('assignedUsers');
            foreach ($schedule->assignedUsers as $user) {
                $questions = [];
                foreach ($schedule->questions_count as $marks => $amount) {
                    foreach (Question::whereMarks($marks)->get()->random(intval($amount))->pluck(['id'])->toArray() as $question_id)
                        array_push($questions, $question_id);
                }
                $user->pivot->questions = $questions;
                $user->pivot->save();
            }
            $schedule->save();
        }

        return redirect()->back();
    }

    public function finishTest(ExamSchedule $schedule)
    {
        if(!$schedule->isActive())
            abort(Response::HTTP_NOT_FOUND);

        $schedule->load('assignedUsers');

        foreach ($schedule->assignedUsers as $user){
            $this->computeResultAndEnd($user->pivot);
        }

        $schedule->finished_at = Carbon::now();
        $schedule->save();

        GenerateResultPDF::dispatch($schedule);

        return redirect()->back();
    }

    public function getResult(ExamSchedule $schedule)
    {
        $fileName = "{$schedule->id}_result.pdf";
        return response()->file(Storage::path($fileName));
    }

    public function applyTest(ExamSchedule $schedule)
    {
        $user = $schedule->assignedUsers()->find(auth()->id());
        if (!$schedule->isActive() || $user == null || $user->pivot->commenced_at != null || $user->pivot->finished_at != null)
            abort(Response::HTTP_NOT_FOUND);

        if ($user->pivot->commenecd_at == null) {
            $user->pivot->commenced_at = Carbon::now();
            $user->pivot->save();
        }

        return redirect(route('schedule.solve_test', ['schedule' => $schedule->id]));
    }

    /**
     * @param ExamSchedule $schedule
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function solveTest(ExamSchedule $schedule)
    {

        $user = $schedule->assignedUsers()->find(auth()->id());

        if (!$schedule->isActive() || $user == null || $user->pivot->commenced_at == null || $user->pivot->finished_at != null)
            abort(Response::HTTP_NOT_FOUND);

        /*
         * Questions
         */
        $questions = Question::whereIn('id', $user->pivot->questions)->paginate(1);
        $currentQuestion = $questions[0];
        /** @var Question $currentQuestion */
        $currentQuestion->load('answers');

        /*
         * Countdown
         */
        $timestring = Carbon::createFromFormat("H:i", $schedule->time_span);
        $endtime = $user->pivot->commenced_at->addHours($timestring->hour)->addMinutes($timestring->minute)->toDateTimeString();

        /*
         * Answers
         */

        $answers = $user->pivot->answers;

        return view('schedule.solve', compact('schedule', 'questions', 'answers', 'currentQuestion', 'endtime'));
    }

    public function submitAnswer(Request $request, ExamSchedule $schedule)
    {

        $user = $schedule->assignedUsers()->find(auth()->id());

        if (!$schedule->isActive() || $user == null || $user->pivot->commenced_at == null || $user->pivot->finished_at != null)
            abort(Response::HTTP_NOT_FOUND);

        $this->validate($request, [
            'answer_id' => 'required|exists:answers,id'
        ]);

        $answers = $user->pivot->answers;
        $answer_id = $request->input('answer_id');

        $question = Answer::find($answer_id)->question;

        if ($answers == null) {
            $answers = [$answer_id];
        } else {
            $key = array_search($answer_id, $answers);
            if ($key !== false)
                array_splice($answers, $key, 1);
            else {
                if (!$question->is_multi_answered) {
                    foreach ($question->answers->pluck('id')->toArray() as $iter) {
                        $key = array_search($iter, $answers);
                        if ($key !== false)
                            array_splice($answers, $key, 1);
                    }
                }
                array_push($answers, $answer_id);
            }
        }
        $user->pivot->answers = $answers;
        $user->pivot->save();

        return response()->json(['message' => 'Answer Recorded Successfully', 'status_code' => Response::HTTP_OK]);

    }

    public function endTestAttempt(Request $request, ExamSchedule $schedule)
    {
        $user = $schedule->assignedUsers()->find(auth()->id());

        if (!$schedule->isActive() || $user == null || $user->pivot->commenced_at == null || $user->pivot->finished_at != null)
            abort(Response::HTTP_NOT_FOUND);

        $this->computeResultAndEnd($user->pivot);

        $request->session()->flash('success', "Exam has now ended and submitted successfully. Let's hope for success now.");

        return redirect(route('home'));
    }

    private function computeResultAndEnd($pivot)
    {
        if($pivot->answers != null) {
            $submittedAnswers = $pivot->answers;
            $score = $pivot->score;
            $questions = $pivot->questions;
            foreach ($questions as $question_id) {

                $question = Question::find($question_id);
                $correctAnswers = $question->answers()->whereIsCorrectAnswer(true)->pluck('id')->toArray();
                $instances = 0;
                foreach ($correctAnswers as $correctAnswer) {
                    $singleKey = array_search($correctAnswer, $submittedAnswers);
                    if ($singleKey !== false) {
                        $instances++;
                        array_splice($submittedAnswers, $singleKey, 1);
                    }
                }
                if ($instances === count($correctAnswers)) {
                    $incorrectAnswers = $question->answers()->whereIsCorrectAnswer(false)->pluck('id')->toArray();
                    $instances = 0;
                    foreach ($incorrectAnswers as $incorrectAnswer) {
                        $singleKey = array_search($incorrectAnswer, $submittedAnswers);
                        if ($singleKey !== false) {
                            $instances++;
                            array_splice($submittedAnswers, $singleKey, 1);
                        }
                    }
                    if ($instances == 0)
                        $score += $question->marks;
                }

            }
            $pivot->score = $score;
        }
        $pivot->finished_at = Carbon::now();
        $pivot->save();
    }

}
