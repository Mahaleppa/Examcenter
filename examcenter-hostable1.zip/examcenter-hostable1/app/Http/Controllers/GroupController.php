<?php

namespace App\Http\Controllers;

use App\Group;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class GroupController extends Controller
{
    public function index()
    {
        $groups = Group::orderBy('name')->get();
        return view('group.index',compact('groups'));
    }

    public function create()
    {
        return view('group.create');
    }

    public function show(Group $group)
    {
        $group ->load(['users','creator', 'categories']);
        return view('group.show', compact('group'));
    }

    public function store(Request $request)
    {
        $this->validate($request,[
            'name' => 'required|alpha_num'
        ]);
        $group = auth()->user()->createdGroups()->create([
            'name' => $request->input('name'),
            'is_admin'=> ($request->has('is_admin')) ? true : false,
        ]);

        return redirect(route('groups.show', ['group' => $group->id]));
    }

    public function updateNameView(Group $group)
    {
        return view('group.editName', compact('group'));
    }

    public function updateName(Request $request,Group $group)
    {
        $this->validate($request,[
            'name' => 'required|alpha_num'
        ]);
        if ($group->name != $request->input('name'))
        {
            $group->name = $request->input('name');
            $group->save();
            $request->session()->flash("success", "Group renamed to <strong>{$group->name}</strong> successfully");
        }
        else {
            $request->session()->flash("success", "Entered name was same as before, no modification required.");
        }

        return redirect(route('groups.show', compact('group')));
    }

    public function deleteView(Group $group)
    {
        $reliedUsers = $group->users()->whereHas('groups', null, '=', 1)->get();
        return view('group.delete', compact('reliedUsers','group'));
    }

    public function delete(Request $request, Group $group)
    {
        if (!!$group->users()->whereHas('groups', null, '=', 1)->count()) {
            return redirect(route('groups.delete.view', ['group' => $group->id]));
        }
        $group->users()->detach();
        try {
            $group->delete();
        } catch (\Exception $e) {
            $request->session()->flash("danger", "Group <strong>{$group->name}</strong> could not be deleted!");
            return back();
        }
        $request->session()->flash("success", "Group <strong>{$group->name}</strong> deleted successfully");

        return redirect(route('groups'));
    }

}
