<?php

namespace App\Http\Controllers;

use App\Events\ExamScheduled;
use App\Exam;
use App\ExamSchedule;
use App\Group;
use App\Question;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class ExamController extends Controller
{
    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $exams = Exam::orderBy('name')->get();
        return view('exam.index', compact('exams'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create()
    {
        return view('exam.create');
    }

    public function show(Exam $exam)
    {
        $exam->load(['questions','creator']);
        return view('exam.show', compact('exam'));
    }

    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|alpha_num'
        ]);
        /** @var Exam $exam */
        $exam = \Auth::user()->createdExams()->create([
            'name' => $request->input('name')
        ]);
        $request->session()->flash('success', "Exam <strong>{$exam->name}</strong> created successfully");
        return redirect(route('exams.show', ['exam' => $exam->id]));
    }

    /**
     * @param Exam $exam
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function updateView(Exam $exam)
    {
        return view('exam.edit', compact('exam'));
    }

    /**
     * @param Request $request
     * @param Exam $exam
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, Exam $exam)
    {
        $this->validate($request, [
            'name' => 'required|alpha_num'
        ]);
        if ($exam->name != $request->input('name')) {
            $exam->name = $request->input('name');
            $exam->save();
            $request->session()->flash("success", "Exam renamed to <strong>{$exam->name}</strong> successfully");
        } else {
            $request->session()->flash("success", "Entered name was same as before, no modification required.");
        }
        return redirect(route('exams'));
//        return redirect(route('categories.show', compact('category')));
    }

    /**
     * @param Exam $exam
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function deleteView(Exam $exam)
    {
        $reliedSchedules = null;

        return view('exam.delete', compact('reliedSchedules', 'exam'));
    }

    /**
     * @param Request $request
     * @param Exam $exam
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @internal param Category $category
     */
    public function delete(Request $request, Exam $exam)
    {
        /*if (!!$exam->groups()->whereHas('categories', null, '=', 1)->count()) {
            return redirect(route('exams.delete.view', ['exam' => $exam->id]));
        }
        $exam->groups()->detach();
        */
        try {
            $exam->delete();
        } catch (\Exception $e) {
            $request->session()->flash("danger", "Exam <strong>{$exam->name}</strong> could not be deleted!");
            return back();
        }
        $request->session()->flash("success", "Exam <strong>{$exam->name}</strong> deleted successfully");

        return redirect(route('exams'));
    }

    public function createQuestionView(Exam $exam)
    {
        return view('question.create', compact('exam'));
    }

    public function createQuestion(Request $request, Exam $exam)
    {

        $this->validate($request,
            [
                'description' => 'required',
                'marks' => 'required|numeric|min:1',
                'answerCount' => 'required|numeric|min:2',
                'answer_correct' => 'required|min:1'
            ],
            [
                'answer_correct.required' => 'At least one correct answer must be selected'
            ]
        );

        if ($request->has('isMultiAnswered'))
            $this->validate($request, [
                'answer_correct' => 'array|min:2'
            ]);

        foreach (range(1, $request->input('answerCount')) as $iter) {
            $this->validate($request,
                [
                    "answer_{$iter}_description" => 'required'
                ]
            );
        }

        $questionData = [
            'description' => $request->input('description'),
            'marks' => $request->input('marks'),
            'user_id' => auth()->id()
        ];

        if ($request->has('isMultiAnswered'))
            $questionData['is_multi_answered'] = true;

        /** @var Question $question */
        $question = $exam->questions()->create($questionData);

        foreach (range(1, $request->input('answerCount')) as $iter) {
            $answerData = [
                'description' => $request->input("answer_{$iter}_description")
            ];

            if ($question->is_multi_answered) {
                if (array_search($iter, $request->input('answer_correct')) !== false)
                    $answerData['is_correct_answer'] = true;
            } else
                if ($request->input('answer_correct') == $iter)
                    $answerData['is_correct_answer'] = true;

            $question->answers()->create($answerData);
        }

        $request->session()->flash('success', "Question <strong><a href='{$question->link()}'>@{$question->id}</a></strong> created successfully");

        return redirect(route('exams.questions.create', ['exam' => $exam->id]));
    }

    public function createScheduleView(Exam $exam){
        $marksOfQuestion = $exam->questions()->select('marks', DB::raw('count(*) as total'))->groupBy('marks')->get();
        $groups = Group::orderBy('name')->get();
        return view('schedule.create', compact('exam', 'marksOfQuestion', 'groups'));
    }

    /**
     * @param Request $request
     * @param Exam $exam
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws ValidationException
     */
    public function createSchedule(Request $request, Exam $exam){
        $this->validate($request, [
            'name' => 'required|alpha_num',
            'description' => 'required',
            'time_span' => 'required|date_format:H:i',
            'marks' => 'required|array|min:1',
            'groups' => 'required|array|min:1',
            'groups.*' => 'exists:groups,id'
        ]);

        $hasSomeQuestion = false;

        foreach ($request->input('marks') as $marks=>$amount){
            if(Question::whereMarks($marks)->count() <= 0)
                throw ValidationException::withMessages(["No question with marks '$marks' exists"]);
            if($amount > 0)
                $hasSomeQuestion = true;
        }

        if(!$hasSomeQuestion)
            throw ValidationException::withMessages(['Please select at least one set of questions for the schedule']);

        /** @var ExamSchedule $schedule */
        $schedule = $exam->schedules()->create([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'questions_count' => $request->input('marks'),
            'time_span' => $request->input('time_span'),
            'user_id' => auth()->id(),
        ]);

        $request->session()->flash('success', "Exam has been scheduled and notified successfully. <strong><a href='{$schedule->link()}'>View Schedule</a></strong>");

        event(new ExamScheduled($exam, $schedule, $request));

        return redirect($exam->link());

    }
}
