<?php

namespace App;

use App\Helpers\UuidGen;
use Emadadly\LaravelUuid\Uuids;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Exam
 *
 * @property-read \App\User $creator
 * @mixin \Eloquent
 */
class Exam extends Model
{

    use Uuids;

    public $incrementing = false;

    protected $fillable = ['id', 'name', 'user_id'];

    public function creator()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function questions(){
        return $this->hasMany(Question::class);
    }

    public function schedules(){
        return $this->hasMany(ExamSchedule::class);
    }

    public function link()
    {
        return route('exams.show', ['exam' => $this->id]);
    }
}
