<?php

namespace App;

use App\Helpers\UuidGen;
use Emadadly\LaravelUuid\Uuids;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Pivot;
use Ramsey\Uuid\Uuid;

class ScheduleAssignment extends Pivot
{
    use Uuids;

    protected $fillable = ['id', 'user_id', 'schedule_id', 'questions', 'answers', 'commenced_at', 'finished_at', 'score'];

    protected $dates = ['commenced_at', 'finished_at', 'created_at', 'updated_at'];

    public $incrementing = false;

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function schedule(){
        return $this->belongsTo(ExamSchedule::class);
    }

    /*
     * Data Manipulators
     */

    public function setQuestionsAttribute($array){
        $this->attributes['questions'] = (count($array) > 0) ? serialize($array) : null;
    }

    public function getQuestionsAttribute($value){
        return (!!$value) ? unserialize($value) : $value;
    }

    public function setAnswersAttribute($array){
        $this->attributes['answers'] =  (count($array) > 0) ? serialize($array) : null;
    }

    public function getAnswersAttribute($value){
        return (!!$value) ? unserialize($value) : $value;
    }


    /*
     * Helpers
     */

    public static function generateId(){
        return strtoupper(Uuid::uuid4()->toString());
    }
}
