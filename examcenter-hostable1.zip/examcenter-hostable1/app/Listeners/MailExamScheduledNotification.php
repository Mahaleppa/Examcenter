<?php

namespace App\Listeners;

use App\Events\ExamScheduled;
use App\Mail\ExamScheduleNotitificationMail;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

class MailExamScheduledNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param ExamScheduled $event
     * @return void
     */
    public function handle(ExamScheduled $event)
    {
        foreach ($event->examSchedule->assignedUsers as $user){
            Mail::to($user)->send(new ExamScheduleNotitificationMail($event->examSchedule, $user));
        }
    }
}
