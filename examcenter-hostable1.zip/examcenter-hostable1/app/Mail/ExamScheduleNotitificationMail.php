<?php

namespace App\Mail;

use App\ExamSchedule;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class ExamScheduleNotitificationMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var ExamSchedule
     */
    protected $examSchedule;
    /**
     * @var User
     */
    protected $user;

    /**
     * Create a new message instance.
     *
     * @param ExamSchedule $schedule
     * @param User $user
     */
    public function __construct(ExamSchedule $schedule, User $user)
    {
        $this->examSchedule = $schedule;
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('schedule.mail')->with([
            'user' => $this->user,
            'schedule' => $this->examSchedule
        ]);
    }
}
