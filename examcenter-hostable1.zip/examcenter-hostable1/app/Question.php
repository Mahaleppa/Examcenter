<?php

namespace App;

use App\Helpers\UuidGen;
use Emadadly\LaravelUuid\Uuids;
use Illuminate\Database\Eloquent\Model;


/**
 * App\Question
 *
 * @mixin \Eloquent
 * @property int $id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Question whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Question whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Question whereUpdatedAt($value)
 */
class Question extends Model
{
    use Uuids;

    public $incrementing = false;

    protected $fillable = ['id', 'description', 'marks', 'is_multi_answered', 'exam_id', 'user_id'];

    public function answers(){
        return $this->hasMany(Answer::class);
    }

    public function creator(){
        return $this->belongsTo(User::class, 'user_id');
    }

    public function exam(){
        return $this->belongsTo(Exam::class);
    }

    public function link(){
        return route('questions.show', ['question' => $this->id]);
    }
}
