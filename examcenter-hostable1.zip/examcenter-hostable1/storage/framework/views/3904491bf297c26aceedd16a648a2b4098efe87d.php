<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 1.5em; margin-bottom: 3em;">
        <div class="row">
            <?php if($errors->any()): ?>
                <div class="col-md-8 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-body alert alert-danger">
                            <ul>
                                <?php $__empty_1 = true; $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-body">
                        Question belongs to <strong><a href="<?php echo e($exam->link()); ?>"><?php echo e($exam->name); ?></a></strong>
                    </div>
                </div>
                <form action="<?php echo e(route('exams.questions.store', ['exam' => $exam->id])); ?>" method="post">
                    <question-create-component csrf_token="<?php echo e(csrf_token()); ?>"><span class="text-muted">Loading...</span></question-create-component>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>