

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                <h5><?php echo e($user->name); ?></h5>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Active Schedules
                    </div>
                    <div class="panel-body">
                        <ul class="list-group" style="margin-bottom: 0;">
                            <?php $__empty_1 = true; $__currentLoopData = $activeSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($schedule->isActive()): ?>
                                    <a class="list-group-item" href="<?php echo e($schedule->link()); ?>"
                                       style="border: 0; <?php echo (array_first($activeSchedules) == $schedule) ?: 'border-top: 1px solid #f5f5f5;'; ?>">
                                        <?php echo e($schedule->name); ?>

                                        <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-muted" style="border: 0;">
                                    No schedules are active for now
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Assigned Schedules
                    </div>
                    <div class="panel-body">
                        <ul class="list-group" style="margin-bottom: 0;">
                            <?php $__empty_1 = true; $__currentLoopData = $user->assignedSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a class="list-group-item" href="<?php echo e($schedule->link()); ?>"
                                   style="border: 0; <?php echo ($user->assignedSchedules->first() == $schedule) ?: 'border-top: 1px solid #f5f5f5;'; ?>">
                                    <?php echo e($schedule->name); ?>

                                    <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-muted" style="border: 0;">
                                    No schedules are assigned
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        User Details
                    </div>
                    <div class="panel-body" style="padding-top: 8px;">
                        <ul class="list-group" style="margin-bottom: 0;">
                            <li class="list-group-item" style="border: 0;">
                                Email Id: <a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a>
                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Created by: <a href="<?php echo e($user->creator->link()); ?>">   <!--$group->creator->link()-->
                                    <?php echo e($user->creator->name); ?>

                                </a>
                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Created: <?php echo e($user->created_at->diffForHumans()); ?>

                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Last updated: <?php echo e($user->updated_at->diffForHumans()); ?>

                            </li>
                        </ul>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Group List
                    </div>
                    <div class="panel-body">
                        <ul class="list-group" style="margin-bottom:0">
                            <?php $__empty_1 = true; $__currentLoopData = $user->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a class="list-group-item" href="<?php echo e($group->link()); ?>"
                                   style="border: 0; <?php echo ($user->groups->first() == $group) ?: 'border-top: 1px solid #f5f5f5;'; ?>">
                                    <?php echo e($group->name); ?>

                                    <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-muted" style="border: 0;">
                                    No groups are assigned
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>