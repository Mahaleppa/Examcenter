<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5>All Schedules</h5>
                </span>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-body" style="padding-left: 28px;">
                    <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a class="list-group-item" href="<?php echo e($schedule->link()); ?>"
                           style="border: 0; <?php echo ($schedules->first() == $schedule) ?: 'border-top: 1px solid #f5f5f5;'; ?>">
                            <?php echo e($schedule->name); ?>

                            <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-muted" style="border: 0;">
                            No schedules available
                        </li>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>