<?php $__env->startSection('content'); ?>
    <div class="container" style="padding-bottom: 64px;">
        <?php echo Form::open(['url' => route('users.store')]); ?>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        Personal Details
                    </div>
                    <div class="panel-body" style="padding: 32px;">
                        
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('name', 'Name', ['class' => 'control-label']); ?>

                            <?php echo Form::text('name', old('name'), ['class' => 'form-control']); ?>

                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        Credentials
                    </div>
                    <div class="panel-body" style="padding: 32px;">
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('email', 'Email', ['class' => 'control-label']); ?>

                            <?php echo Form::text('email', old('email'), ['class' => 'form-control']); ?>

                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('password', 'Password', ['class' => 'control-label']); ?>

                            <?php echo Form::password('password', ['class' => 'form-control']); ?>

                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('password_confirmation', 'Confirm Password', ['class' => 'control-label']); ?>

                            <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        Groups
                    </div>
                    <div class="panel-body" style="padding: 32px;">
                        <?php if($errors->has('groups')): ?>
                            <span class="help-block alert alert-danger">
                                    <strong><?php echo e($errors->first('groups')); ?></strong>
                            </span>
                        <?php endif; ?>

                        <ul class="list-group" style="margin-bottom: 0;">
                            <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="list-group-item col-md-6" style="border: 0;">
                                    <?php echo Form::checkbox('groups[]', $group->id, null, ['id' => $group->id]); ?>

                                    <?php echo Form::label($group->id, $group->name, ['class' => 'control-label']); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item col-md-6 text-muted" style="border: 0;">
                                    No groups avail in this category
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <?php echo Form::submit('Create User', ['class' => 'btn btn-primary']); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>