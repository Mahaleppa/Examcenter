<?php $__env->startSection('content'); ?>
    <div class="container" style="padding-bottom: 64px;">
        <?php echo Form::open(['url' => route('groups.store')]); ?>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        Create Group
                    </div>
                    <div class="panel-body" style="padding: 32px;">
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('name', 'Name', ['class' => 'control-label']); ?>

                            <?php echo Form::text('name', old('name'), ['class' => 'form-control']); ?>

                            <li class="list-group-item col-md-6" style="border: 0;">
                            <?php echo Form::checkbox('is_admin', 'is_admin', false ); ?>

                            <?php echo Form::label('is_admin', ' isAdmin?', ['class' => 'control-label']); ?>

                            </li>
                                <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php echo Form::submit('Create Group', ['class' => 'btn btn-primary']); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>