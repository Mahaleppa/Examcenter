<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5><span class="text-muted">Schedule: </span><?php echo e($schedule->name); ?></h5>
                </span>
                    <span class="pull-right category-modifiers" style="margin: .7em;">
                    <?php if(!$schedule->isCommenced()): ?>
                            <a href="<?php echo e(route('schedule.commence_test', ['schedule' => $schedule->id])); ?>"
                               class="btn btn-primary btn-sm" style="margin-right: 1em;" data-toggle="tooltip"
                               title="Commence Exam">
                            <span class="glyphicon glyphicon-send"></span>
                        </a>
                        <?php endif; ?>
                        <?php if($schedule->isActive()): ?>
                            <a href="<?php echo e(route('schedule.finish_test', ['schedule' => $schedule->id])); ?>"
                               class="btn btn-sm btn-danger" style="margin-right: 1em;" data-toggle="tooltip"
                               title="End Exam">
                            <span class="glyphicon glyphicon-stop"></span>
                        </a>
                        <?php endif; ?>
                        <?php if($schedule->isFinished()): ?>
                            <?php if($schedule->generatedPDF): ?>
                                <a href="<?php echo e(route('schedule.result', ['schedule' => $schedule->id])); ?>" target="_blank"
                                   class="btn btn-info btn-sm" style="margin-right: 1em;" data-toggle="tooltip"
                                   title="Show Result">
                                <span class="glyphicon glyphicon-download"></span>
                            </a>
                            <?php else: ?>
                                <a href="#" class="btn btn-info btn-sm" style="margin-right: 1em;" data-toggle="tooltip"
                                   title="Result is being generated. Please be patient." disabled="">
                                <span class="glyphicon glyphicon-download"></span>
                            </a>
                            <?php endif; ?>
                        <?php endif; ?>
                </span>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8">
                    <div class="panel panel-default ">
                        <div class="panel-heading" style="display: inline-block; width: 100%;">
                            <div class="pull-left">
                                Schedule Description
                            </div>
                            <div class="pull-right">
                                <a href="<?php echo e($schedule->exam->link()); ?>" class="btn btn-xs btn-primary">Go to exam <span
                                            class="glyphicon glyphicon-chevron-right"></span></a>
                            </div>
                        </div>
                        <div class="panel-body" style="padding: 28px;">
                            <?php echo app('Indal\Markdown\Parser')->parse($schedule->description); ?>
                        </div>
                    </div>
                    <div class="panel panel-default ">
                        <div class="panel-heading">
                            Assigned Users
                        </div>
                        <div class="panel-body">
                            <ul class="list-group" style="margin-bottom: 0;">
                                <?php $__empty_1 = true; $__currentLoopData = $schedule->assignedUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <a class="list-group-item col-md-6"
                                       style="border: 0;" href="<?php echo e($user->link()); ?>">
                                        <?php echo e($user->name); ?>

                                        <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                    </a>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li class="list-group-item text-muted" style="border: 0;"></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-default ">
                        <div class="panel-heading">
                            Question Preferences
                        </div>
                        <div class="panel-body">
                            <ul class="list-group" style="margin-bottom: 0;">
                                <?php $__empty_1 = true; $__currentLoopData = $schedule->questions_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark=>$amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li class="list-group-item"
                                        style="border: 0; <?php echo (array_first($schedule->questions_count) == $amount) ?: 'border-top: 1px solid #f5f5f5;'; ?>">
                                        <strong><?php echo e($mark); ?></strong> <?php if($mark == 1): ?> mark <?php else: ?> marks <?php endif; ?>:
                                        <strong><?php echo e($amount); ?></strong> <?php if($amount == 1): ?> question <?php else: ?> questions <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li class="list-group-item text-muted" style="border: 0;">No question allotted</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Schedule Details
                        </div>
                        <div class="panel-body">
                            <ul class="list-group" style="margin-bottom: 0;">
                                <li class="list-group-item" style="border: 0;">
                                    Created by: <a href="<?php echo e($schedule->creator->link()); ?>">
                                        <?php echo e($schedule->creator->name); ?>

                                    </a>
                                </li>
                                <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                    Created: <?php echo e($schedule->created_at->diffForHumans()); ?>

                                </li>
                                <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                    Last updated: <?php echo e($schedule->updated_at->diffForHumans()); ?>

                                </li>
                                <?php if($schedule->isCommenced()): ?>
                                    <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                        Commenced: <?php echo e($schedule->created_at->diffForHumans()); ?>

                                    </li>
                                <?php endif; ?>
                                <?php if($schedule->isFinished()): ?>
                                    <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                        Finished: <?php echo e($schedule->created_at->diffForHumans()); ?>

                                    </li>
                                <?php endif; ?>
                                <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                    Status: <?php if($schedule->isActive()): ?> <span class="text-success">Active</span> <?php else: ?>
                                        <span class="text-danger">Inactive</span> <?php endif; ?>
                                </li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>