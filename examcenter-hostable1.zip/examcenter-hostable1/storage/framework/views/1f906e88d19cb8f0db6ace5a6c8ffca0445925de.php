

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <?php if($errors->has('groups')): ?>
                <div class="col-8" style="padding: 1em;">
                    <span class="help-block alert alert-danger alert-auto-dismiss alert-dismissable fade in">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong><?php echo e($errors->first('groups')); ?></strong>
                    </span>
                </div>
            <?php endif; ?>

            <div class="col-md-4 col-md-offset-2">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        Unlink groups in <strong><a href="<?php echo e($category->link()); ?>"
                                                    style="color: inherit;"><?php echo e($category->name); ?></a></strong>
                    </div>
                    <?php echo Form::open(['url' => route('categories.edit.groups.remove', ['category' => $category->id])]); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <div class="panel-body" style="padding: 28px 28px 0;">
                        <div class="alert alert-info">
                            Select the groups to be removed from <strong><?php echo e($category->name); ?></strong>
                        </div>

                        <ul class="list-group" style="margin-bottom: 0;">
                            <?php $__empty_1 = true; $__currentLoopData = $linkedGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="list-group-item col-md-6" style="border: 0;">
                                    <?php if($group->categories->count() == 1): ?>
                                        <?php echo Form::checkbox('groups[]', $group->id, null, ['id' => $group->id, 'disabled', 'data-toggle' => 'tooltip', 'title' => 'Belongs to only one category' ]); ?>

                                        <?php echo Form::label($group->id, $group->name, ['class' => 'control-label', 'disabled', 'data-toggle' => 'tooltip', 'title' => 'Belongs to only one category' ]); ?>

                                    <?php else: ?>
                                        <?php echo Form::checkbox('groups[]', $group->id, null, ['id' => $group->id]); ?>

                                        <?php echo Form::label($group->id, $group->name, ['class' => 'control-label']); ?>

                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-muted" style="border: 0;">
                                    No groups available
                                </li>
                            <?php endif; ?>
                        </ul>

                    </div>
                    <div class="panel-body" style="padding: 0 28px 28px;">
                        <hr>
                        <?php echo Form::submit('Unlink Groups', ['class' => 'btn btn-danger btn-sm pull-right']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>

            </div>
            <div class="col-md-4">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        Link groups to <strong><a href="<?php echo e($category->link()); ?>"
                                                  style="color: inherit;"><?php echo e($category->name); ?></a></strong>
                    </div>
                    <?php echo Form::open(['url' => route('categories.edit.groups.store', ['category' => $category->id])]); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="panel-body" style="padding: 28px; padding-bottom: 0">
                        <div class="alert alert-info">
                            Select the groups to be added to <strong><?php echo e($category->name); ?></strong>
                        </div>

                        <ul class="list-group" style="margin-bottom: 0;">
                            <?php $__empty_1 = true; $__currentLoopData = $unlinkedGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="list-group-item col-md-6" style="border: 0;">
                                    <?php echo Form::checkbox('groups[]', $group->id, null, ['id' => $group->id]); ?>

                                    <?php echo Form::label($group->id, $group->name, ['class' => 'control-label']); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-muted" style="border: 0;">
                                    No groups available
                                </li>
                            <?php endif; ?>
                        </ul>

                    </div>
                    <div class="panel-body" style="padding: 28px; padding-top: 0;">
                        <hr>
                        <?php echo Form::submit('Link Groups', ['class' => 'btn btn-primary btn-sm pull-right']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>