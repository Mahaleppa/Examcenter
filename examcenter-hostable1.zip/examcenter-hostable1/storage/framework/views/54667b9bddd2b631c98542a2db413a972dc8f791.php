<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3" style="padding: 0;">
                <div class="panel panel-info">
                    <div class="panel-heading" style="display: inline-block; width: 100%">
                        <div class="pull-left">
                            Navigation
                        </div>
                        <div class="pull-right label label-danger"
                             style="font-size: 11px; font-weight: bold !important;">
                            <span class="glyphicon glyphicon-time"></span>
                            <span id="timer">Initializing timer</span>
                        </div>
                    </div>
                    <div class="panel-body"
                         style="max-height: 200px; padding-top: 1em; padding-bottom: 1.8em; overflow-y: scroll;">
                        <?php $__currentLoopData = range(1, $questions->total()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-2" style="margin: .3em;">
                                <a href="<?php echo e($questions->url($iter)); ?>"
                                   class="btn btn-<?php echo ($questions->currentPage() == $iter) ? 'primary' : ' default' ?>"><?php echo e($iter); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="panel-footer" style="display: inline-block; width: 100%; height: 4em;">
                        <?php if($questions->currentPage() != 1): ?>
                            <a class="btn btn-default btn-sm pull-left" href="<?php echo e($questions->previousPageUrl()); ?>"><span
                                        class="glyphicon glyphicon-chevron-left"></span> Previous</a>
                        <?php endif; ?>
                        <?php if($questions->currentPage() != $questions->lastPage()): ?>
                            <a class="btn btn-default btn-sm pull-right" href="<?php echo e($questions->nextPageUrl()); ?>">Next
                                <span
                                        class="glyphicon glyphicon-chevron-right"></span></a>
                        <?php endif; ?>
                    </div>
                    <div class="panel-footer">
                        <a href="<?php echo e(route('schedule.solve_test.end', ['schedule' => $schedule->id])); ?>" class="btn btn-warning btn-block">End Test</a>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row">

                    <div class="col-md-10 col-md-offset-1">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                Description
                            </div>
                            <div class="panel-body" style="word-break: break-all;">
                                <?php echo app('Indal\Markdown\Parser')->parse($currentQuestion->description); ?>
                            </div>
                            <div class="panel-footer" style="height: 3.3em;">
                                <span class="text-muted" style="position: relative;float: right;">
                                    <?php echo e($currentQuestion->marks); ?> <?php echo ($currentQuestion->marks == 1) ? 'mark' : 'marks' ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <?php $__currentLoopData = $currentQuestion->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <schedule-test-answer-component answer_id="<?php echo e($answer->id); ?>"
                                                                answer_description="<?php echo e($answer->description); ?>"
                                                                is_multi_answered="<?php echo e($currentQuestion->is_multi_answered); ?>"
                                                                answer_checked="<?php echo ($answers != null && array_search($answer->id, $answers) !== false) ? true : false ?>"
                                                                answer_submit_route="<?php echo e(route('schedule.solve_test.submit_answer', ['schedule' => $schedule->id])); ?>">
                                    <div class="col-md-8 col-md-offset-2">
                                        <div class="panel panel-default">
                                            <div class="panel-body">
                                                <span class="text-muted">Loading Answer...</span>
                                            </div>
                                        </div>
                                    </div>
                                </schedule-test-answer-component>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col-md-8 col-md-offset-2" style="padding-right: .4em; margin-top: 1em;">
                            <div class="pull-right">
                                <?php if($questions->currentPage() != 1): ?>
                                    <a class="btn btn-default" href="<?php echo e($questions->previousPageUrl()); ?>"
                                       style="margin-right 0;margin-left: 1em;"><span
                                                class="glyphicon glyphicon-chevron-left"></span> Previous</a>
                                <?php endif; ?>
                                <?php if($questions->currentPage() != $questions->lastPage()): ?>
                                    <a class="btn btn-primary" href="<?php echo e($questions->nextPageUrl()); ?>"
                                       style="margin-left: 1em;">Next <span
                                                class="glyphicon glyphicon-chevron-right"></span></a>
                                <?php else: ?>
                                    <a class="btn btn-warning" href="<?php echo e(route('schedule.solve_test.end', ['schedule' => $schedule->id])); ?>" style="margin-left: 1em;">End Test <span
                                                class="glyphicon glyphicon-ok-sign"></span></a>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>