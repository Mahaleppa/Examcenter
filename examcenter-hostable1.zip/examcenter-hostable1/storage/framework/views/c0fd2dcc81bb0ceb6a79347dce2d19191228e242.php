

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5><?php echo e($exam->name); ?></h5>
                </span>
                <span class="pull-right category-modifiers" style="margin: .7em;">
                    <a href="<?php echo e(route('exams.schedules.create', ['exam' => $exam->id])); ?>" class="btn btn-link btn-sm"
                       style="margin-right: 1em;" data-toggle="tooltip" title="Schedule this exam">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </a>
                    <a href="<?php echo e(route('exams.edit.view', ['exam' => $exam->id])); ?>"
                       class="btn btn-link btn-sm" style="margin-right: 1em;" data-toggle="tooltip" title="Edit name">
                        <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                    <a href="<?php echo e(route('exams.delete.view', ['exam' => $exam->id])); ?>"
                       class="btn btn-danger btn-sm" style="margin-right: 1em;" data-toggle="tooltip" title="Delete">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7">
                <div class="panel panel-default">
                    <div class="panel-heading" style="display: inline-block; width: 100%;">
                        <div class="pull-left">
                            Questions in <?php echo e($exam->name); ?>

                        </div>
                        <div class="pull-right">
                            <a href="<?php echo e(route('exams.questions.create', ['exam' => $exam->id])); ?>"
                               class="btn btn-xs btn-primary" style="color: #fff;" data-toggle="tooltip"
                               title="Create Question">
                                <span class="glyphicon glyphicon-plus"></span>
                            </a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="list-group" style="margin-bottom: 0;">
                            <?php $__empty_1 = true; $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a class="list-group-item" href="<?php echo e($question->link()); ?>"
                                   style="border: 0; <?php echo ($exam->questions->first() == $question) ?: 'border-top: 1px solid #f5f5f5;'; ?>">
                                    Question <?php echo e($key+1); ?>

                                    <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-muted" style="border: 0;">
                                    No questions available
                                </li>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Details
                    </div>
                    <div class="panel-body">
                        <ul class="list-group" style="margin-bottom: 0;">
                            <li class="list-group-item" style="border: 0;">
                                Created by: <a href="<?php echo e($exam->creator->link()); ?>">
                                    <?php echo e($exam->creator->name); ?>

                                </a>
                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Created: <?php echo e($exam->created_at->diffForHumans()); ?>

                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Last updated: <?php echo e($exam->updated_at->diffForHumans()); ?>

                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-md-5 col-md-push-0 pull-right">
                <div class="panel panel-default">
                    <div class="panel-heading" style="display: inline-block; width: 100%;">
                        Schedules of <?php echo e($exam->name); ?>

                    </div>
                    <div class="panel-body">
                        <div class="list-group" style="margin-bottom: 0;">
                            <?php $__empty_1 = true; $__currentLoopData = $exam->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a class="list-group-item" href="<?php echo e($schedule->link()); ?>"
                                   style="border: 0; <?php echo ($exam->schedules->first() == $schedule) ?: 'border-top: 1px solid #f5f5f5;'; ?>">
                                    <?php echo e($schedule->name); ?>

                                    <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-muted" style="border: 0;">
                                    No schedules available
                                </li>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>