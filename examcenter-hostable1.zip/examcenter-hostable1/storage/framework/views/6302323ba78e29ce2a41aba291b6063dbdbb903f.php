

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5><?php echo e($category->name); ?></h5>
                </span>
                <span class="pull-right category-modifiers" style="margin: .7em;">
                    <a href="<?php echo e(route('categories.edit.name.view', ['category' => $category->id])); ?>"
                       class="btn btn-link btn-sm" style="margin-right: 1em;" data-toggle="tooltip" title="Edit name">
                        <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                    <a href="<?php echo e(route('categories.delete.view', ['category' => $category->id])); ?>"
                       class="btn btn-danger btn-sm" style="margin-right: 1em;" data-toggle="tooltip" title="Delete">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7">
                <div class="panel panel-default">
                    <div class="panel-heading" style="display: inline-block; width: 100%;">
                        <div class="pull-left">
                            Groups in <?php echo e($category->name); ?>

                        </div>
                        <div class="pull-right">
                            <a href="<?php echo e(route('categories.edit.groups.view', ['category' => $category->id])); ?>" class="btn btn-xs btn-primary" style="color: #fff;" data-toggle="tooltip" title="Edit groups">
                                <span class="glyphicon glyphicon-pencil"></span>
                            </a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="list-group" style="margin-bottom: 0;">
                            <?php $__empty_1 = true; $__currentLoopData = $category->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a class="list-group-item" href="<?php echo e($group->link()); ?>"
                                   style="border: 0; <?php echo ($category->groups->first() == $group) ?: 'border-top: 1px solid #f5f5f5;'; ?>">
                                    <?php echo e($group->name); ?>

                                    <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-muted" style="border: 0;">
                                    No groups available
                                </li>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Details
                    </div>
                    <div class="panel-body">
                        <ul class="list-group" style="margin-bottom: 0;">
                            <li class="list-group-item" style="border: 0;">
                                Created by: <a href="<?php echo e($category->creator->link()); ?>">
                                    <?php echo e($category->creator->name); ?>

                                </a>
                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Created: <?php echo e($category->created_at->diffForHumans()); ?>

                            </li>
                            <li class="list-group-item" style="border: 0; border-top: 1px solid #f5f5f5;">
                                Last updated: <?php echo e($category->updated_at->diffForHumans()); ?>

                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>