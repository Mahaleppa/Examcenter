<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo Form::open(['url' => route('change_password')]); ?>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                    Change Password
                    </div>
                    <div class="panel-body">
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('password', 'Password', ['class' => 'control-label']); ?>

                            <?php echo Form::password('password', ['class' => 'form-control']); ?>

                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('password_confirmation', 'Confirm Password', ['class' => 'control-label']); ?>

                            <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

                        </div>
                    </div>
                </div>
                <?php echo Form::submit('Make Changes', ['class' => 'btn btn-primary']); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>