<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading" style="display: inline-block; width: 100%;">
                        <div class="pull-left">
                            Question <?php echo e('@'); ?><?php echo e($question->id); ?>

                        </div>
                        <div class="pull-right">
                            <a href="#" class="btn btn-xs btn-danger" data-toggle="tooltip"
                               title="Delete Question">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </div>
                        <div class="pull-right">
                            <a class="btn btn-primary btn-xs" href="<?php echo e($question->exam->link()); ?>"
                               style="margin-right: 1em;">Go to exam <span
                                        class="glyphicon glyphicon-chevron-right"></span></a>
                        </div>
                    </div>
                    <div class="panel-body" style="word-break: break-all;">
                        <?php echo app('Indal\Markdown\Parser')->parse($question->description); ?>
                    </div>
                    <div class="panel-footer">
                        <span>
                        <span class="glyphicon glyphicon-info-sign"></span>
                            <?php if($question->is_multi_answered): ?>
                                This question has multiple correct answers
                            <?php else: ?>
                                This question has only one correct answer
                            <?php endif; ?>
                        </span>
                        <span class="text-muted" style="float: right;">
                            <?php echo e($question->marks); ?> <?php echo ($question->marks == 1) ?  'mark' : 'marks' ?>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-md-offset-2">

                <div class="row ">
                    <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-8 col-md-offset-2">
                            <div class="panel <?php if($answer->is_correct_answer): ?> panel-success <?php else: ?> panel-default <?php endif; ?>">
                                <div class="panel-heading" style="display: inline-block; width: 100%;">
                                    <div class="pull-left">
                                        Answer <?php echo e($key+1); ?>

                                    </div>
                                    <div class="pull-right">
                                        <?php if($answer->is_correct_answer): ?>
                                            <span class="glyphicon glyphicon-ok" style="color: inherit;"
                                                  data-toggle="tooltip"
                                                  title="Correct Answer"></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <?php echo app('Indal\Markdown\Parser')->parse($answer->description); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>