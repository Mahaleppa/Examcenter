<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                <span class="pull-left">
                    <h5>All Exams</h5>
                </span>
                <span class="pull-right category-modifiers">
                    <a href="<?php echo e(route('exams.create')); ?>"
                       class="btn btn-link" style="margin-right: 1em; vertical-align: middle; margin: .4em;" data-toggle="tooltip" title="Create Exam">
                        <span class="glyphicon glyphicon-plus"></span>
                    </a>
                </span>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-body" style="padding-left: 28px;">
                <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a class="list-group-item" href="<?php echo e($exam->link()); ?>"
                       style="border: 0; <?php echo ($exams->first() == $exam) ?: 'border-top: 1px solid #f5f5f5;'; ?>">
                        <?php echo e($exam->name); ?>

                        <span class="glyphicon glyphicon-chevron-right pull-right text-muted"></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item text-muted" style="border: 0;">
                        No exams available
                    </li>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>