<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
            <?php if($errors->any()): ?>
                    <div class="panel panel-default">
                        <div class="panel-body alert alert-danger">
                            <ul>
                                <?php $__empty_1 = true; $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
        <?php endif; ?>
        <?php echo Form::open(['url' => route('exams.schedules.store', ['exam' => $exam->id])]); ?>

                    <div class="panel panel-default">
                    <div class="panel-body">
                        Scheduling exam <strong><a href="<?php echo e($exam->link()); ?>"><?php echo e($exam->name); ?></a></strong>
                    </div>
                    </div>

                    <div class="panel panel-primary">
                    <div class="panel-heading">
                        Schedule Details
                    </div>
                    <div class="panel-body" style="padding: 28px;">
                        <div class="form-group">
                            <?php echo Form::text('name', null, ['placeholder' => 'Name', 'class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                            Description
                        </div>
                        <div class="panel-body">
                            <schedule-description-component><span class="text-muted">Loading...</span>
                            </schedule-description-component>
                        </div>
                        </div>
                </div>
                <div class="form-group">
                    <?php echo Form::label('time_span', 'Time span for exam (hh:mm)', ['class' => 'control-label']); ?>

                    <?php echo Form::text('time_span', null,['placeholder' => 'hh:mm', 'class' => 'form-control']); ?>

                </div>
            </div>
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading">
                Questions Allotment
            </div>
            <div class="panel-body" style="padding: 28px;">
                <?php $__currentLoopData = $marksOfQuestion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row"
                         style="<?php ($marksOfQuestion->last() == $mark) ?: 'margin-bottom: 2em;' ?>">
                        <?php echo Form::label("marks[$mark->marks]", "$mark->marks " . (($mark->marks == '1') ? "mark" : "marks"), ['class' => 'col-md-2 control-label', 'style' => 'line-height: 2.9;']); ?>

                        <div class="col-md-10">
                            <?php echo Form::select("marks[$mark->marks]",range(0, $mark->total), null, ['class' => 'form-control']); ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="panel panel-primary">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Groups to be assigned to schedule
                </div>
                <div class="panel-body" style="padding: 32px;">
                    <ul class="list-group" style="margin-bottom: 0;">
                        <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="list-group-item col-md-6" style="border: 0;">
                                <?php echo Form::checkbox('groups[]', $group->id, null, ['id' => $group->id]); ?>

                                <?php echo Form::label($group->id, $group->name, ['class' => 'control-label']); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="list-group-item col-md-6 text-muted" style="border: 0;">
                                No groups avail in this category
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php echo Form::submit('Create Schedule', ['class' => 'btn btn-primary']); ?>

        <?php echo Form::close(); ?>

                </div>
            </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>